// Сборка игры одним автономным HTML-файлом: весь JS инлайнится
// обычным (не module) <script>, поэтому dist/index.html работает
// и на сервере, и по file:// (двойной клик).
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const res = await build({
  entryPoints: ['src/scene.js'],
  bundle: true,
  format: 'iife',
  minify: true,
  target: 'es2020',
  write: false,
  logLevel: 'warning',
});

const js = res.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');

let html = readFileSync('index.html', 'utf8');
const marker = '<script type="module" src="./src/scene.js"></script>';
if (!html.includes(marker)) throw new Error('script marker not found in index.html');
html = html.replace(marker, () => `<script>${js}</script>`);

mkdirSync('dist', { recursive: true });
writeFileSync('dist/index.html', html);
console.log(`dist/index.html — ${(html.length / 1024).toFixed(1)} KB, автономный файл`);
