// —— Звук: весь SFX синтезируется Web Audio, без файлов ——

let ctx = null, master = null, ambient = null;
let muted = localStorage.getItem('sr_mute') === '1';

function ac() {
  if (!ctx) {
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.35;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function env(node, t0, a, d, peak = 1) {
  node.gain.setValueAtTime(0, t0);
  node.gain.linearRampToValueAtTime(peak, t0 + a);
  node.gain.exponentialRampToValueAtTime(0.0001, t0 + a + d);
}

function tone({ type = 'square', f0 = 440, f1 = null, a = 0.005, d = 0.15, vol = 0.5, delay = 0 }) {
  if (muted) return;
  const c = ac(), t0 = c.currentTime + delay;
  const o = c.createOscillator(), g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f0, t0);
  if (f1 !== null) o.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), t0 + a + d);
  env(g, t0, a, d, vol);
  o.connect(g).connect(master);
  o.start(t0); o.stop(t0 + a + d + 0.05);
}

function noise({ d = 0.4, vol = 0.6, f = 1200, q = 0.8, delay = 0 }) {
  if (muted) return;
  const c = ac(), t0 = c.currentTime + delay;
  const len = Math.ceil(c.sampleRate * d);
  const buf = c.createBuffer(1, len, c.sampleRate);
  const ch = buf.getChannelData(0);
  for (let i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = c.createBufferSource(); src.buffer = buf;
  const flt = c.createBiquadFilter(); flt.type = 'lowpass'; flt.frequency.value = f; flt.Q.value = q;
  const g = c.createGain(); env(g, t0, 0.005, d, vol);
  src.connect(flt).connect(g).connect(master);
  src.start(t0);
}

export const sfx = {
  get muted() { return muted; },
  toggleMute() {
    muted = !muted;
    localStorage.setItem('sr_mute', muted ? '1' : '0');
    if (master) master.gain.value = muted ? 0 : 0.35;
    if (!muted) startAmbient();
    return muted;
  },
  unlock() { ac(); startAmbient(); },

  shoot()      { tone({ type: 'sawtooth', f0: 900, f1: 240, d: 0.12, vol: 0.25 }); },
  enemyShoot() { tone({ type: 'square', f0: 420, f1: 140, d: 0.14, vol: 0.18 }); },
  hit()        { noise({ d: 0.12, vol: 0.3, f: 2000 }); },
  hullHit()    { noise({ d: 0.25, vol: 0.5, f: 700 }); tone({ type: 'triangle', f0: 140, f1: 60, d: 0.2, vol: 0.4 }); },
  explosion()  { noise({ d: 0.7, vol: 0.8, f: 900 }); tone({ type: 'sine', f0: 120, f1: 30, d: 0.6, vol: 0.6 }); },
  bigExplosion(){ noise({ d: 1.4, vol: 1, f: 600 }); tone({ type: 'sine', f0: 90, f1: 22, d: 1.2, vol: 0.8 }); },
  buy()        { tone({ type: 'sine', f0: 660, d: 0.07, vol: 0.3 }); tone({ type: 'sine', f0: 990, d: 0.09, vol: 0.3, delay: 0.07 }); },
  sell()       { tone({ type: 'sine', f0: 990, d: 0.07, vol: 0.3 }); tone({ type: 'sine', f0: 660, d: 0.09, vol: 0.3, delay: 0.07 }); },
  error()      { tone({ type: 'square', f0: 160, d: 0.18, vol: 0.3 }); },
  upgrade()    { [523, 659, 784].forEach((f, i) => tone({ type: 'triangle', f0: f, d: 0.15, vol: 0.3, delay: i * 0.09 })); },
  dock()       { [392, 523, 659, 784].forEach((f, i) => tone({ type: 'sine', f0: f, d: 0.2, vol: 0.28, delay: i * 0.1 })); },
  bossHorn()   { tone({ type: 'sawtooth', f0: 110, f1: 55, d: 1.2, vol: 0.6 }); tone({ type: 'sawtooth', f0: 165, f1: 82, d: 1.2, vol: 0.4, delay: 0.15 }); },
  victory()    { [523, 659, 784, 1047].forEach((f, i) => tone({ type: 'triangle', f0: f, d: 0.35, vol: 0.35, delay: i * 0.16 })); },
};

function startAmbient() {
  if (muted || ambient || !ctx) return;
  const o1 = ctx.createOscillator(), o2 = ctx.createOscillator(), g = ctx.createGain();
  o1.type = 'sine'; o1.frequency.value = 55;
  o2.type = 'sine'; o2.frequency.value = 55.7;   // биения
  g.gain.value = 0.045;
  o1.connect(g); o2.connect(g); g.connect(master);
  o1.start(); o2.start();
  ambient = { o1, o2, g };
}
