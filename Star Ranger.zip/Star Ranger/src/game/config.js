// —— Конфигурация: вся балансировка и контент здесь ——

export const GOODS = [
  { id: 'prov', name: 'Провиант',     base: 10 },
  { id: 'min',  name: 'Минералы',     base: 18 },
  { id: 'tech', name: 'Техника',      base: 45 },
  { id: 'med',  name: 'Медикаменты',  base: 60 },
  { id: 'lux',  name: 'Роскошь',      base: 110 },
];

// profile < 1 — планета производит товар (дёшево), > 1 — потребляет (дорого)
export const PLANETS = [
  { name: 'Гринвуд', desc: 'Аграрный мир. Дешёвый провиант, голодны до роскоши.',
    orbit: 640, size: 36, color: '#6fcf7a', dark: '#2c6b3c', speed: 0.030, angle0: 0.7,
    profile: { prov: 0.5, min: 1.2, tech: 1.5, med: 1.2, lux: 1.8 } },
  { name: 'Магма', desc: 'Горнодобывающая колония. Минералы — по цене камня.',
    orbit: 1000, size: 30, color: '#e07a4a', dark: '#7a3520', speed: 0.021, angle0: 2.4,
    profile: { prov: 1.8, min: 0.5, tech: 1.3, med: 1.4, lux: 1.5 } },
  { name: 'Технополис', desc: 'Научный центр системы. Техника прямо с конвейера.',
    orbit: 1360, size: 32, color: '#5aa8e0', dark: '#274a6b', speed: 0.016, angle0: 4.1,
    profile: { prov: 1.3, min: 1.4, tech: 0.55, med: 1.1, lux: 1.6 } },
  { name: 'Фармасити', desc: 'Медицинский рай. Лекарства дешевле воды.',
    orbit: 1720, size: 34, color: '#c98ae0', dark: '#5c3a70', speed: 0.012, angle0: 5.5,
    profile: { prov: 1.2, min: 1.5, tech: 1.2, med: 0.55, lux: 1.7 } },
];

export const UPGRADES = [
  { id: 'laser',  name: 'Лазерная установка', levels: ['Mk I', 'Mk II', 'Mk III'], prices: [0, 800, 2200] },
  { id: 'engine', name: 'Двигатель',          levels: ['Mk I', 'Mk II', 'Mk III'], prices: [0, 700, 1800] },
  { id: 'hull',   name: 'Броня корпуса',      levels: ['Mk I', 'Mk II', 'Mk III'], prices: [0, 750, 2000], bonus: [0, 40, 100] },
  { id: 'cargo',  name: 'Расширение трюма',   levels: ['Mk I', 'Mk II', 'Mk III'], prices: [0, 500, 1400], bonus: [0, 15, 35] },
];

export const CFG = {
  sunRadius: 90,
  radiationRadius: 250,     // ближе — корпус плавится
  radiationDps: 14,

  ship: {
    accel: 230,             // * (1 + 0.35*(engine-1))
    turn: 3.6,              // рад/с
    maxSpeed: 300,
    brakeDamp: 2.2,
    drag: 0.22,
    maxHull: 100,
    maxFuel: 100,
    fuelBurn: 3.2,          // в секунду при тяге
    fuelBurnBrake: 1.6,
    startCredits: 150,
    cargoBase: 20,
  },

  laser: {
    speed: 640,
    dmg: [0, 12, 16, 20],   // по уровню
    cooldown: [0, 0.30, 0.22, 0.16],
    life: 1.4,
  },

  pirate: {
    hpBase: 42, hpPerKill: 8, hpMax: 110,
    speed: 185,
    preferDist: 260,
    fireRange: 520,
    fireCdMin: 1.9, fireCdMax: 3.0,
    bulletSpeed: 320, bulletDmg: 6,
    bountyBase: 130, bountyPerKill: 16,
    spawnEvery: 24, maxActive: 4,
    cargoDropChance: 0.55,
  },

  boss: {
    name: 'Адмирал Крэг',
    hp: 950, speed: 165, preferDist: 300,
    fireCd: 1.1, bulletSpeed: 360, bulletDmg: 13,
    bounty: 3000,
    spawnAtKills: 6,
  },

  asteroid: {
    count: 42, beltR: 1180, beltW: 130,
    minR: 10, maxR: 26,
    hp: 30, dmgOnHit: 9,
    mineralChance: 0.4,
  },

  economy: {
    tick: 24,               // раз в столько секунд рынок движется
    swing: 0.16,            // ±16% за тик
    minMul: 0.38, maxMul: 2.3,
    sellRatio: 0.8,         // продажа — 80% от биржевой цены
    fuelPrice: 2,           // за единицу
    repairPrice: 3,         // за единицу корпуса
  },

  dockRange: 130,
};

export function mulberry32(a) {
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
