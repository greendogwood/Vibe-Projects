// —— Ввод: клавиатура, блокировка браузерных дефолтов ——

const down = new Set();
const pressed = new Set();   // «нажато в этом кадре» — читается и чистится циклом

const BLOCK = new Set(['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight']);

addEventListener('keydown', (e) => {
  if (BLOCK.has(e.code)) e.preventDefault();
  if (!e.repeat) pressed.add(e.code);
  down.add(e.code);
});
addEventListener('keyup', (e) => down.delete(e.code));
addEventListener('blur', () => down.clear());

export const input = {
  down: (code) => down.has(code),
  wasPressed: (code) => pressed.has(code),
  endFrame() { pressed.clear(); },

  // Игровые оси
  thrust() { return down.has('KeyW') || down.has('ArrowUp'); },
  brake()  { return down.has('KeyS') || down.has('ArrowDown'); },
  left()   { return down.has('KeyA') || down.has('ArrowLeft'); },
  right()  { return down.has('KeyD') || down.has('ArrowRight'); },
  fire()   { return down.has('Space'); },
};
