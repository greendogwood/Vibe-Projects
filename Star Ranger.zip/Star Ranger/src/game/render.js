// —— Отрисовка: canvas 2D, параллакс-звёзды, солнце, планеты, корабли ——

import { CFG, mulberry32 } from './config.js';

const TAU = Math.PI * 2;

// Процедурные слои звёзд (детерминированы — не «плывут» между кадрами)
function makeStars(seed, n, tile, sizeMul) {
  const rand = mulberry32(seed);
  const s = [];
  for (let i = 0; i < n; i++) {
    s.push({
      x: rand() * tile, y: rand() * tile,
      r: (0.4 + rand() * 1.1) * sizeMul,
      tw: rand() * TAU,
      c: rand() < 0.12 ? '#9fd8ff' : rand() < 0.08 ? '#ffd8a8' : '#dfe8f5',
    });
  }
  return s;
}
const TILE = 2400;
const LAYERS = [
  { stars: makeStars(11, 220, TILE, 0.8), par: 0.15, alpha: 0.55 },
  { stars: makeStars(22, 140, TILE, 1.1), par: 0.35, alpha: 0.75 },
  { stars: makeStars(33, 80, TILE, 1.5), par: 0.6, alpha: 1 },
];

// Туманности
function makeNebulas() {
  const rand = mulberry32(77);
  const cols = ['94,80,200', '40,140,180', '180,70,140', '30,100,200'];
  const out = [];
  for (let i = 0; i < 6; i++) {
    out.push({
      x: (rand() * 2 - 1) * 2200, y: (rand() * 2 - 1) * 2200,
      r: 500 + rand() * 700, c: cols[i % cols.length], a: 0.05 + rand() * 0.04,
    });
  }
  return out;
}
const NEBULAS = makeNebulas();

export const camera = { x: 0, y: 0 };

export function updateCamera(cam, target, dt) {
  const look = 0.35;
  const tx = target.x + target.vx * look, ty = target.y + target.vy * look;
  const k = 1 - Math.exp(-5 * dt);
  cam.x += (tx - cam.x) * k;
  cam.y += (ty - cam.y) * k;
}

// ——— Корабли ———
function drawShip(ctx, angle, draw) {
  ctx.save();
  ctx.rotate(angle);
  draw();
  ctx.restore();
}

function shipPlayer(ctx, t, thrusting) {
  // Пламя двигателя
  if (thrusting) {
    const fl = 10 + Math.sin(t * 40) * 3;
    ctx.beginPath();
    ctx.moveTo(-12, 4); ctx.lineTo(-12 - fl, 0); ctx.lineTo(-12, -4);
    ctx.fillStyle = '#5ee6ff';
    ctx.globalAlpha = 0.9; ctx.fill(); ctx.globalAlpha = 1;
  }
  ctx.beginPath();
  ctx.moveTo(18, 0); ctx.lineTo(-10, 9); ctx.lineTo(-14, 5); ctx.lineTo(-14, -5); ctx.lineTo(-10, -9);
  ctx.closePath();
  const g = ctx.createLinearGradient(-14, 0, 18, 0);
  g.addColorStop(0, '#2a6b8a'); g.addColorStop(1, '#8ad8f0');
  ctx.fillStyle = g; ctx.fill();
  ctx.strokeStyle = '#b8ecff'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.beginPath(); ctx.ellipse(4, 0, 5, 3, 0, 0, TAU);
  ctx.fillStyle = '#d8f4ff'; ctx.fill();
}

function shipPirate(ctx, pr) {
  const s = pr.boss ? 2.1 : 1;
  ctx.scale(s, s);
  ctx.beginPath();
  ctx.moveTo(15, 0); ctx.lineTo(2, 7); ctx.lineTo(-13, 12); ctx.lineTo(-8, 0); ctx.lineTo(-13, -12); ctx.lineTo(2, -7);
  ctx.closePath();
  ctx.fillStyle = pr.boss ? '#7a1626' : '#8a2a35'; ctx.fill();
  ctx.strokeStyle = pr.boss ? '#ff8a96' : '#e06a75'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.beginPath(); ctx.arc(2, 0, 3.2, 0, TAU);
  ctx.fillStyle = '#ffce5e'; ctx.fill();
}

// ——— Мир ———
export function render(ctx, world, W, H, thrusting) {
  const cam = camera;
  ctx.fillStyle = '#04060d';
  ctx.fillRect(0, 0, W, H);

  // Звёзды
  for (const L of LAYERS) {
    const ox = ((-cam.x * L.par) % TILE + TILE) % TILE;
    const oy = ((-cam.y * L.par) % TILE + TILE) % TILE;
    ctx.fillStyle = '#fff';
    for (const s of L.stars) {
      let x = s.x - ox, y = s.y - oy;
      if (x < -4) x += TILE; if (y < -4) y += TILE;
      if (x > W + 4 || y > H + 4) continue;
      const tw = 0.7 + 0.3 * Math.sin(world.t * 2 + s.tw);
      ctx.globalAlpha = L.alpha * tw;
      ctx.fillStyle = s.c;
      ctx.fillRect(x, y, s.r, s.r);
    }
  }
  ctx.globalAlpha = 1;

  ctx.save();
  ctx.translate(W / 2 - cam.x, H / 2 - cam.y);

  // Туманности
  for (const n of NEBULAS) {
    const g = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.r);
    g.addColorStop(0, `rgba(${n.c},${n.a})`);
    g.addColorStop(1, `rgba(${n.c},0)`);
    ctx.fillStyle = g;
    ctx.fillRect(n.x - n.r, n.y - n.r, n.r * 2, n.r * 2);
  }

  // Орбиты
  ctx.strokeStyle = 'rgba(120,160,200,0.12)';
  ctx.lineWidth = 1;
  for (const pl of world.planets) {
    ctx.beginPath(); ctx.arc(0, 0, pl.orbit, 0, TAU); ctx.stroke();
  }

  // Радиационный пояс солнца
  ctx.save();
  ctx.setLineDash([8, 10]);
  ctx.strokeStyle = 'rgba(255,140,60,0.28)';
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(0, 0, CFG.radiationRadius, 0, TAU); ctx.stroke();
  ctx.restore();

  // Солнце
  const flick = 1 + Math.sin(world.t * 3.1) * 0.03 + Math.sin(world.t * 7.7) * 0.02;
  let g = ctx.createRadialGradient(0, 0, 0, 0, 0, CFG.sunRadius * 4);
  g.addColorStop(0, 'rgba(255,220,140,0.55)');
  g.addColorStop(0.35, 'rgba(255,160,60,0.18)');
  g.addColorStop(1, 'rgba(255,120,40,0)');
  ctx.fillStyle = g;
  ctx.fillRect(-CFG.sunRadius * 4, -CFG.sunRadius * 4, CFG.sunRadius * 8, CFG.sunRadius * 8);
  g = ctx.createRadialGradient(0, 0, 0, 0, 0, CFG.sunRadius * flick);
  g.addColorStop(0, '#fff8e0');
  g.addColorStop(0.6, '#ffd870');
  g.addColorStop(1, '#ff9838');
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(0, 0, CFG.sunRadius * flick, 0, TAU); ctx.fill();

  // Планеты
  for (const pl of world.planets) drawPlanet(ctx, pl, cam, W, H);

  // Астероиды
  ctx.strokeStyle = '#8a97a8'; ctx.fillStyle = '#39424e'; ctx.lineWidth = 1.5;
  for (const a of world.asteroids) {
    ctx.save();
    ctx.translate(a.x, a.y); ctx.rotate(a.rot); ctx.scale(a.r, a.r);
    ctx.beginPath();
    ctx.moveTo(a.verts[0][0], a.verts[0][1]);
    for (let i = 1; i < a.verts.length; i++) ctx.lineTo(a.verts[i][0], a.verts[i][1]);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
  }

  // Пули
  for (const b of world.bullets) {
    ctx.strokeStyle = b.from === 'p' ? '#7df3ff' : '#ff7a6e';
    ctx.lineWidth = b.from === 'p' ? 2.5 : 2;
    ctx.beginPath();
    ctx.moveTo(b.x - b.vx * 0.02, b.y - b.vy * 0.02);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  // Пираты
  for (const pr of world.pirates) {
    ctx.save();
    ctx.translate(pr.x, pr.y);
    drawShip(ctx, pr.angle, () => shipPirate(ctx, pr));
    ctx.restore();
    // Полоска HP
    const w = pr.boss ? 64 : 30;
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(pr.x - w / 2, pr.y - (pr.boss ? 46 : 26), w, 4);
    ctx.fillStyle = pr.boss ? '#ff5e6e' : '#e08a5e';
    ctx.fillRect(pr.x - w / 2, pr.y - (pr.boss ? 46 : 26), w * Math.max(0, pr.hp / pr.maxHp), 4);
    if (pr.boss) {
      ctx.fillStyle = '#ff8a96';
      ctx.font = '11px ui-monospace,monospace';
      ctx.textAlign = 'center';
      ctx.fillText(CFG.boss.name, pr.x, pr.y - 52);
    }
  }

  // Игрок
  const p = world.player;
  ctx.save();
  ctx.translate(p.x, p.y);
  drawShip(ctx, p.angle, () => shipPlayer(ctx, world.t, thrusting));
  ctx.restore();

  // Частицы
  for (const pt of world.particles) {
    ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
    ctx.fillStyle = pt.color;
    ctx.fillRect(pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
  }
  ctx.globalAlpha = 1;

  ctx.restore();
}

function drawPlanet(ctx, pl, cam, W, H) {
  // Вне экрана — только подпись не рисуем; тело дёшево, рисуем всегда
  const g = ctx.createRadialGradient(pl.x - pl.size * 0.4, pl.y - pl.size * 0.4, pl.size * 0.1, pl.x, pl.y, pl.size);
  g.addColorStop(0, pl.color);
  g.addColorStop(1, pl.dark);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(pl.x, pl.y, pl.size, 0, TAU); ctx.fill();
  // Атмосфера
  ctx.strokeStyle = pl.color + '55';
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(pl.x, pl.y, pl.size + 2.5, 0, TAU); ctx.stroke();
  // Подпись
  const sx = pl.x - cam.x + W / 2, sy = pl.y - cam.y + H / 2;
  if (sx > -80 && sx < W + 80 && sy > -40 && sy < H + 40) {
    ctx.fillStyle = 'rgba(200,225,245,0.75)';
    ctx.font = '12px "Segoe UI",sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(pl.name, pl.x, pl.y + pl.size + 16);
  }
}

// ——— Миникарта ———
export function renderMinimap(mctx, world) {
  const S = 170, half = S / 2;
  const scale = half / 1950;
  mctx.clearRect(0, 0, S, S);
  mctx.save();
  mctx.translate(half, half);

  mctx.strokeStyle = 'rgba(120,160,200,0.25)';
  mctx.lineWidth = 0.7;
  for (const pl of world.planets) {
    mctx.beginPath(); mctx.arc(0, 0, pl.orbit * scale, 0, TAU); mctx.stroke();
  }
  // Солнце
  mctx.fillStyle = '#ffd870';
  mctx.beginPath(); mctx.arc(0, 0, 4, 0, TAU); mctx.fill();
  // Пояс
  mctx.fillStyle = 'rgba(140,150,170,0.5)';
  for (const a of world.asteroids) mctx.fillRect(a.x * scale - 0.5, a.y * scale - 0.5, 1.2, 1.2);
  // Планеты
  for (const pl of world.planets) {
    mctx.fillStyle = pl.color;
    mctx.beginPath(); mctx.arc(pl.x * scale, pl.y * scale, 2.6, 0, TAU); mctx.fill();
  }
  // Пираты
  for (const pr of world.pirates) {
    mctx.fillStyle = pr.boss ? '#ff3050' : '#ff7a6e';
    const r = pr.boss ? 3.4 : 2;
    mctx.beginPath(); mctx.arc(pr.x * scale, pr.y * scale, r, 0, TAU); mctx.fill();
  }
  // Игрок — треугольник по курсу
  const p = world.player;
  mctx.save();
  mctx.translate(p.x * scale, p.y * scale);
  mctx.rotate(p.angle);
  mctx.fillStyle = '#5ee6ff';
  mctx.beginPath(); mctx.moveTo(4, 0); mctx.lineTo(-3, 2.6); mctx.lineTo(-3, -2.6); mctx.closePath(); mctx.fill();
  mctx.restore();

  mctx.restore();
}
