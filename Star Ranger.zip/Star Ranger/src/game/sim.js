// —— Симуляция мира: орбиты, экономика, пираты, бой, частицы ——
// Мир — чистые данные; updateWorld двигает его на фиксированный dt
// и складывает события в world.events (их читают звук и тосты).

import { CFG, GOODS, PLANETS, mulberry32 } from './config.js';

const TAU = Math.PI * 2;
const dist2 = (ax, ay, bx, by) => { const dx = ax - bx, dy = ay - by; return dx * dx + dy * dy; };
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;

export function createWorld(seed = (Math.random() * 1e9) | 0) {
  const rand = mulberry32(seed);

  const planets = PLANETS.map((p) => ({
    ...p, angle: p.angle0, x: 0, y: 0, prices: {},
  }));
  const world = {
    rand, t: 0, events: [],
    cycle: 1,                  // цикл охоты на адмирала; каждый следующий — тяжелее
    planets,
    asteroids: [],
    pirates: [],
    bullets: [],
    particles: [],
    player: null,
    priceTimer: CFG.economy.tick,
    spawnTimer: 12,            // первый пират — не сразу, дать осмотреться
    bossSpawned: false,
    bossDefeated: false,
    nearPlanet: null,          // планета в зоне стыковки
  };

  // Стартовые цены
  for (const pl of planets) rollPrices(world, pl, true);

  // Пояс астероидов
  for (let i = 0; i < CFG.asteroid.count; i++) {
    const a = rand() * TAU;
    const r = CFG.asteroid.beltR + (rand() * 2 - 1) * CFG.asteroid.beltW;
    world.asteroids.push({
      x: Math.cos(a) * r, y: Math.sin(a) * r,
      vx: (rand() - 0.5) * 14, vy: (rand() - 0.5) * 14,
      r: CFG.asteroid.minR + rand() * (CFG.asteroid.maxR - CFG.asteroid.minR),
      rot: rand() * TAU, vr: (rand() - 0.5) * 0.8,
      hp: CFG.asteroid.hp,
      verts: makeRockVerts(rand),
    });
  }

  // Игрок — у первой планеты
  const p0 = planets[0];
  movePlanet(p0, 0);
  world.player = {
    x: p0.x + 90, y: p0.y, vx: 0, vy: 0, angle: Math.atan2(-p0.y, -p0.x),
    hull: CFG.ship.maxHull, maxHull: CFG.ship.maxHull,
    fuel: CFG.ship.maxFuel, maxFuel: CFG.ship.maxFuel,
    credits: CFG.ship.startCredits,
    cargo: {}, cargoMax: CFG.ship.cargoBase,
    laser: 1, engine: 1, hullLvl: 1, cargoLvl: 1,
    kills: 0, earned: 0, fireCd: 0,
  };
  return world;
}

function makeRockVerts(rand) {
  const n = 7 + (rand() * 4 | 0), v = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU, r = 0.72 + rand() * 0.4;
    v.push([Math.cos(a) * r, Math.sin(a) * r]);
  }
  return v;
}

function movePlanet(pl, t) {
  const a = pl.angle0 + pl.speed * t;
  pl.x = Math.cos(a) * pl.orbit;
  pl.y = Math.sin(a) * pl.orbit;
}

// —— Экономика ——
function rollPrices(world, pl, first = false) {
  const E = CFG.economy;
  for (const g of GOODS) {
    const baseP = g.base * pl.profile[g.id];
    if (first) {
      pl.prices[g.id] = Math.round(baseP * (0.9 + world.rand() * 0.2));
    } else {
      const swing = 1 + (world.rand() * 2 - 1) * E.swing;
      pl.prices[g.id] = Math.round(clamp(pl.prices[g.id] * swing, g.base * E.minMul, g.base * E.maxMul));
    }
  }
}

export function cargoUsed(p) {
  let n = 0; for (const k in p.cargo) n += p.cargo[k]; return n;
}

// —— Частицы (пул) ——
function burst(world, x, y, { n = 14, color = '#ffb45e', speed = 160, life = 0.7, size = 3 }) {
  for (let i = 0; i < n; i++) {
    const a = world.rand() * TAU, s = speed * (0.3 + world.rand() * 0.7);
    world.particles.push({
      x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
      life: life * (0.5 + world.rand() * 0.5), maxLife: life, color, size,
    });
  }
  if (world.particles.length > 600) world.particles.splice(0, world.particles.length - 600);
}

function fireBullet(world, x, y, angle, speed, dmg, from) {
  world.bullets.push({
    x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
    dmg, from, life: CFG.laser.life,
  });
}

// —— Пираты ——
function spawnPirate(world, boss = false) {
  const p = world.player;
  const a = world.rand() * TAU, d = boss ? 1400 : 1150 + world.rand() * 550;
  const B = CFG.pirate, BO = CFG.boss;
  const cyc = world.cycle - 1; // пройденные циклы усиливают всех
  const hp = boss
    ? Math.round(BO.hp * (1 + 0.35 * cyc))
    : Math.min(B.hpBase + p.kills * B.hpPerKill, B.hpMax + 25 * cyc);
  world.pirates.push({
    x: p.x + Math.cos(a) * d, y: p.y + Math.sin(a) * d,
    vx: 0, vy: 0, angle: a + Math.PI,
    hp, maxHp: hp,
    fireCd: 1 + world.rand() * 1.5,
    bounty: boss ? Math.round(BO.bounty * (1 + 0.5 * cyc)) : B.bountyBase + p.kills * B.bountyPerKill,
    boss, strafe: world.rand() < 0.5 ? 1 : -1,
  });
  world.events.push(boss ? { type: 'boss' } : { type: 'pirate' });
}

function updatePirate(world, pr, dt) {
  const p = world.player;
  const dx = p.x - pr.x, dy = p.y - pr.y;
  const d = Math.hypot(dx, dy) || 1;
  const B = pr.boss ? CFG.boss : CFG.pirate;

  // Держим дистанцию + боковой дрейф
  const want = B.preferDist;
  const toward = d > want ? 1 : -0.6;
  const ux = dx / d, uy = dy / d;
  const ax = (ux * toward - uy * pr.strafe * 0.55) * B.speed * 2.2;
  const ay = (uy * toward + ux * pr.strafe * 0.55) * B.speed * 2.2;
  pr.vx += ax * dt; pr.vy += ay * dt;
  const sp = Math.hypot(pr.vx, pr.vy);
  if (sp > B.speed) { pr.vx = pr.vx / sp * B.speed; pr.vy = pr.vy / sp * B.speed; }
  pr.x += pr.vx * dt; pr.y += pr.vy * dt;
  pr.angle = Math.atan2(dy, dx);

  if (world.rand() < dt * 0.25) pr.strafe *= -1;

  pr.fireCd -= dt;
  if (pr.fireCd <= 0 && d < (pr.boss ? 640 : CFG.pirate.fireRange)) {
    if (pr.boss) {
      for (const off of [-0.14, 0, 0.14]) fireBullet(world, pr.x, pr.y, pr.angle + off, CFG.boss.bulletSpeed, CFG.boss.bulletDmg, 'e');
      pr.fireCd = CFG.boss.fireCd;
    } else {
      fireBullet(world, pr.x, pr.y, pr.angle + (world.rand() - 0.5) * 0.12, CFG.pirate.bulletSpeed, CFG.pirate.bulletDmg, 'e');
      pr.fireCd = CFG.pirate.fireCdMin + world.rand() * (CFG.pirate.fireCdMax - CFG.pirate.fireCdMin);
    }
    world.events.push({ type: 'enemyShoot' });
  }
}

function killPirate(world, pr) {
  const p = world.player;
  p.credits += pr.bounty; p.earned += pr.bounty; p.kills++;
  burst(world, pr.x, pr.y, { n: pr.boss ? 70 : 30, color: pr.boss ? '#ff5e6e' : '#ffb45e', speed: pr.boss ? 320 : 220, life: pr.boss ? 1.3 : 0.8, size: pr.boss ? 5 : 3 });
  world.events.push({ type: pr.boss ? 'bossDown' : 'pirateDown', bounty: pr.bounty });
  // Груз с борта
  if (!pr.boss && world.rand() < CFG.pirate.cargoDropChance) {
    const g = GOODS[(world.rand() * GOODS.length) | 0];
    const qty = 1 + (world.rand() * 3 | 0);
    if (cargoUsed(p) + qty <= p.cargoMax) {
      p.cargo[g.id] = (p.cargo[g.id] || 0) + qty;
      world.events.push({ type: 'loot', good: g.name, qty });
    }
  }
  if (pr.boss) world.bossDefeated = true;
}

// —— Главный шаг симуляции ——
export function updateWorld(world, dt, input) {
  world.t += dt;
  const p = world.player;
  const S = CFG.ship;

  // Орбиты
  for (const pl of world.planets) movePlanet(pl, world.t);

  // Рынок
  world.priceTimer -= dt;
  if (world.priceTimer <= 0) {
    world.priceTimer = CFG.economy.tick;
    for (const pl of world.planets) rollPrices(world, pl);
    world.events.push({ type: 'market' });
  }

  // Спавн пиратов
  if (!world.bossSpawned || world.pirates.some((x) => x.boss)) {
    world.spawnTimer -= dt;
    if (world.spawnTimer <= 0 && world.pirates.filter((x) => !x.boss).length < CFG.pirate.maxActive) {
      spawnPirate(world);
      world.spawnTimer = CFG.pirate.spawnEvery;
    }
  }
  // Босс выходит на охоту — раз за цикл, счётчик копится через циклы
  if (!world.bossSpawned && p.kills >= world.cycle * CFG.boss.spawnAtKills) {
    world.bossSpawned = true;
    spawnPirate(world, true);
  }

  // — Управление кораблём —
  const engMul = 1 + 0.35 * (p.engine - 1);
  if (input.left()) p.angle -= S.turn * dt;
  if (input.right()) p.angle += S.turn * dt;
  if (input.thrust() && p.fuel > 0) {
    p.vx += Math.cos(p.angle) * S.accel * engMul * dt;
    p.vy += Math.sin(p.angle) * S.accel * engMul * dt;
    p.fuel = Math.max(0, p.fuel - S.fuelBurn * dt);
    if (world.rand() < dt * 30) {
      world.particles.push({
        x: p.x - Math.cos(p.angle) * 14, y: p.y - Math.sin(p.angle) * 14,
        vx: -Math.cos(p.angle) * 90 + (world.rand() - 0.5) * 30,
        vy: -Math.sin(p.angle) * 90 + (world.rand() - 0.5) * 30,
        life: 0.35, maxLife: 0.35, color: '#5ee6ff', size: 2.5,
      });
    }
  }
  if (input.brake() && p.fuel > 0) {
    p.vx -= p.vx * S.brakeDamp * dt;
    p.vy -= p.vy * S.brakeDamp * dt;
    p.fuel = Math.max(0, p.fuel - S.fuelBurnBrake * dt);
  }
  // Мягкий предел скорости
  const maxV = S.maxSpeed * engMul;
  const sp = Math.hypot(p.vx, p.vy);
  if (sp > maxV) { p.vx = p.vx / sp * maxV; p.vy = p.vy / sp * maxV; }
  p.vx -= p.vx * S.drag * dt; p.vy -= p.vy * S.drag * dt;
  p.x += p.vx * dt; p.y += p.vy * dt;

  // Огонь
  p.fireCd -= dt;
  if (input.fire() && p.fireCd <= 0) {
    const L = CFG.laser;
    fireBullet(world, p.x + Math.cos(p.angle) * 16, p.y + Math.sin(p.angle) * 16, p.angle, L.speed, L.dmg[p.laser], 'p');
    if (p.laser >= 2) {
      fireBullet(world, p.x, p.y, p.angle + 0.09, L.speed, L.dmg[p.laser], 'p');
      fireBullet(world, p.x, p.y, p.angle - 0.09, L.speed, L.dmg[p.laser], 'p');
    }
    p.fireCd = L.cooldown[p.laser];
    world.events.push({ type: 'shoot' });
  }

  // Пираты
  for (const pr of world.pirates) updatePirate(world, pr, dt);

  // Пули
  for (const b of world.bullets) {
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
  }

  // Астероиды
  for (const a of world.asteroids) {
    a.x += a.vx * dt; a.y += a.vy * dt; a.rot += a.vr * dt;
  }

  // Частицы
  for (const pt of world.particles) {
    pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.life -= dt;
  }

  // — Столкновения —
  collide(world);

  // Радиация солнца
  const dsun = Math.hypot(p.x, p.y);
  if (dsun < CFG.radiationRadius) {
    p.hull -= CFG.radiationDps * dt;
    if (world.rand() < dt * 2) world.events.push({ type: 'radiation' });
  }

  // Зона стыковки
  world.nearPlanet = null;
  for (const pl of world.planets) {
    if (dist2(p.x, p.y, pl.x, pl.y) < (CFG.dockRange + pl.size) ** 2) { world.nearPlanet = pl; break; }
  }

  // Сбор мусора
  world.bullets = world.bullets.filter((b) => b.life > 0 && !b.dead);
  world.particles = world.particles.filter((pt) => pt.life > 0);
  world.pirates = world.pirates.filter((pr) => !pr.dead);
  world.asteroids = world.asteroids.filter((a) => !a.dead);
}

function damagePlayer(world, dmg, x, y) {
  const p = world.player;
  p.hull -= dmg;
  burst(world, x, y, { n: 8, color: '#ff5e6e', speed: 120, life: 0.4, size: 2 });
  world.events.push({ type: 'hullHit' });
}

function collide(world) {
  const p = world.player;

  for (const b of world.bullets) {
    if (b.from === 'p') {
      // Пули игрока → пираты
      for (const pr of world.pirates) {
        const rr = pr.boss ? 34 : 16;
        if (dist2(b.x, b.y, pr.x, pr.y) < rr * rr) {
          b.dead = true;
          pr.hp -= b.dmg;
          burst(world, b.x, b.y, { n: 5, color: '#ffe65e', speed: 140, life: 0.3, size: 2 });
          world.events.push({ type: 'hit' });
          if (pr.hp <= 0 && !pr.dead) { pr.dead = true; killPirate(world, pr); }
          break;
        }
      }
      // …и астероиды
      if (!b.dead) for (const a of world.asteroids) {
        if (dist2(b.x, b.y, a.x, a.y) < a.r * a.r) {
          b.dead = true;
          a.hp -= b.dmg;
          burst(world, b.x, b.y, { n: 5, color: '#9aa8b8', speed: 110, life: 0.35, size: 2 });
          world.events.push({ type: 'hit' });
          if (a.hp <= 0 && !a.dead) {
            a.dead = true;
            burst(world, a.x, a.y, { n: 18, color: '#8a97a8', speed: 170, life: 0.7, size: 3 });
            world.events.push({ type: 'rockDown' });
            if (world.rand() < CFG.asteroid.mineralChance && cargoUsed(p) < p.cargoMax) {
              p.cargo.min = (p.cargo.min || 0) + 1;
              world.events.push({ type: 'loot', good: 'Минералы', qty: 1 });
            }
          }
          break;
        }
      }
    } else {
      // Вражеские пули → игрок
      if (dist2(b.x, b.y, p.x, p.y) < 14 * 14) {
        b.dead = true;
        damagePlayer(world, b.dmg, b.x, b.y);
      }
    }
  }

  // Игрок ↔ астероиды
  for (const a of world.asteroids) {
    const rr = a.r + 12;
    if (dist2(p.x, p.y, a.x, a.y) < rr * rr) {
      const d = Math.hypot(p.x - a.x, p.y - a.y) || 1;
      const push = (rr - d);
      p.x += (p.x - a.x) / d * push; p.y += (p.y - a.y) / d * push;
      const vn = (p.vx * (p.x - a.x) + p.vy * (p.y - a.y)) / d;
      if (vn < 0) {
        p.vx -= 1.6 * vn * (p.x - a.x) / d;
        p.vy -= 1.6 * vn * (p.y - a.y) / d;
        if (vn < -60) damagePlayer(world, CFG.asteroid.dmgOnHit, p.x, p.y);
      }
    }
  }

  // Игрок ↔ планеты (мягкий отталкиватель — планета твёрдая)
  for (const pl of world.planets) {
    const rr = pl.size + 12;
    const d2 = dist2(p.x, p.y, pl.x, pl.y);
    if (d2 < rr * rr) {
      const d = Math.sqrt(d2) || 1;
      p.x = pl.x + (p.x - pl.x) / d * rr;
      p.y = pl.y + (p.y - pl.y) / d * rr;
      p.vx *= 0.5; p.vy *= 0.5;
    }
  }

  // Игрок ↔ солнце — не даём провалиться внутрь
  const sr = CFG.sunRadius + 10;
  const ds = Math.hypot(p.x, p.y);
  if (ds < sr && ds > 0) {
    p.x = p.x / ds * sr; p.y = p.y / ds * sr;
    p.vx *= -0.4; p.vy *= -0.4;
    damagePlayer(world, 20, p.x, p.y);
  }
}

// —— Торговые действия (вызываются из UI в состоянии стыковки) ——
export function priceOf(planet, goodId) { return planet.prices[goodId]; }
export function sellPrice(planet, goodId) { return Math.max(1, Math.round(planet.prices[goodId] * CFG.economy.sellRatio)); }

export function buyGood(world, planet, goodId, qty) {
  const p = world.player, price = priceOf(planet, goodId);
  for (let i = 0; i < qty; i++) {
    if (p.credits < price) return { ok: false, msg: 'Не хватает кредитов' };
    if (cargoUsed(p) >= p.cargoMax) return { ok: false, msg: 'Трюм полон' };
    p.credits -= price;
    p.cargo[goodId] = (p.cargo[goodId] || 0) + 1;
  }
  return { ok: true };
}

export function sellGood(world, planet, goodId, qty) {
  const p = world.player, price = sellPrice(planet, goodId);
  const have = p.cargo[goodId] || 0;
  const n = Math.min(qty, have);
  if (n <= 0) return { ok: false, msg: 'Нет товара' };
  p.cargo[goodId] = have - n;
  if (p.cargo[goodId] <= 0) delete p.cargo[goodId];
  p.credits += price * n; p.earned += price * n;
  return { ok: true };
}

export function refuel(world) {
  const p = world.player;
  const need = Math.ceil(p.maxFuel - p.fuel);
  if (need <= 0) return { ok: false, msg: 'Бак полон' };
  const cost = need * CFG.economy.fuelPrice;
  if (p.credits < cost) return { ok: false, msg: 'Не хватает кредитов' };
  p.credits -= cost; p.fuel = p.maxFuel;
  return { ok: true };
}

export function repair(world) {
  const p = world.player;
  const need = Math.ceil(p.maxHull - p.hull);
  if (need <= 0) return { ok: false, msg: 'Корпус цел' };
  const cost = need * CFG.economy.repairPrice;
  if (p.credits < cost) return { ok: false, msg: 'Не хватает кредитов' };
  p.credits -= cost; p.hull = p.maxHull;
  return { ok: true };
}

export function buyUpgrade(world, up) {
  const p = world.player;
  const lvl = p[up.id === 'hull' ? 'hullLvl' : up.id === 'cargo' ? 'cargoLvl' : up.id];
  if (lvl >= 3) return { ok: false, msg: 'Максимум' };
  const cost = up.prices[lvl];
  if (p.credits < cost) return { ok: false, msg: 'Не хватает кредитов' };
  p.credits -= cost;
  if (up.id === 'hull') { p.hullLvl++; p.maxHull += up.bonus[p.hullLvl - 1] - (up.bonus[p.hullLvl - 2] || 0); p.hull = p.maxHull; }
  else if (up.id === 'cargo') { p.cargoLvl++; p.cargoMax = CFG.ship.cargoBase + up.bonus[p.cargoLvl - 1]; }
  else p[up.id]++;
  return { ok: true };
}
