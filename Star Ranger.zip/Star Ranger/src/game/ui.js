// —— DOM-интерфейс: HUD, тосты, торговая палуба ——

import { GOODS, UPGRADES, CFG } from './config.js';
import * as sim from './sim.js';
import { sfx } from './audio.js';

const $ = (id) => document.getElementById(id);
const fmt = (n) => n.toLocaleString('ru-RU');

// ——— Тосты ———
const toastBox = () => $('toasts');
export function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast' + (kind ? ' ' + kind : '');
  el.textContent = msg;
  toastBox().appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 350); }, 2600);
  while (toastBox().children.length > 4) toastBox().firstChild.remove();
}

// ——— HUD ———
export function updateHUD(world) {
  const p = world.player;
  $('hull').querySelector('.fill').style.width = Math.max(0, p.hull / p.maxHull * 100) + '%';
  $('fuel').querySelector('.fill').style.width = Math.max(0, p.fuel / p.maxFuel * 100) + '%';
  $('stats').innerHTML =
    `Кредиты: <b>${fmt(p.credits)}</b><br>` +
    `Трюм: <b>${sim.cargoUsed(p)}/${p.cargoMax}</b><br>` +
    `Пираты: <b>${p.kills}</b> · Цикл: <b>${world.cycle}</b>`;
  const need = CFG.boss.spawnAtKills;
  const done = p.kills - (world.cycle - 1) * need;
  $('objective').textContent = world.bossSpawned
    ? `⚠ Адмирал Крэг (цикл ${world.cycle}) в системе — уничтожьте его!`
    : `Цикл ${world.cycle}. Уничтожьте пиратов, чтобы выманить адмирала (${done}/${need}). Торгуйте и качайте корабль.`;
}

export function setDockPrompt(planet) {
  const el = $('dock-prompt');
  if (planet) { el.style.display = 'block'; $('dock-name').textContent = planet.name; }
  else el.style.display = 'none';
}

// ——— Экраны ———
const SCREENS = ['title', 'pause', 'gameover'];
export function showScreen(name) {
  for (const s of SCREENS) $(s).classList.toggle('on', s === name);
  $('trade').classList.toggle('on', name === 'trade');
  const inGame = name === null || name === 'trade';
  $('hud').style.display = inGame ? 'block' : 'none';
  $('minimap').style.display = inGame ? 'block' : 'none';
}

export function fillStats(elId, world) {
  const p = world.player;
  const t = Math.round(world.t);
  const mm = String((t / 60) | 0).padStart(2, '0'), ss = String(t % 60).padStart(2, '0');
  $(elId).innerHTML =
    `Время полёта: <b>${mm}:${ss}</b><br>` +
    `Пройдено циклов: <b>${world.cycle - 1}</b><br>` +
    `Пиратов уничтожено: <b>${p.kills}</b><br>` +
    `Заработано кредитов: <b>${fmt(p.earned)}</b>`;
}

export function fillBestLine(save) {
  $('best-line').textContent = save.best > 0
    ? `Рекорд: ${fmt(save.best)} кредитов · циклов пройдено: ${save.wins}`
    : 'Первый вылет, рейнджер? Удачи.';
}

// ——— Торговая палуба ———
let currentPlanet = null, worldRef = null, onChange = null;

export function openTrade(world, planet, refreshHUD) {
  currentPlanet = planet; worldRef = world; onChange = refreshHUD;
  renderTrade();
}

function act(fn, sound) {
  const r = fn();
  if (r.ok) { sfx[sound](); renderTrade(); onChange(); }
  else { sfx.error(); toast(r.msg, 'warn'); }
}

function renderTrade() {
  const world = worldRef, planet = currentPlanet, p = world.player;
  $('trade-title').textContent = planet.name;
  $('trade-desc').textContent = planet.desc;
  $('trade-credits').textContent = `${fmt(p.credits)} ⨯`;

  // Биржа
  const tb = $('goods-table').querySelector('tbody');
  tb.innerHTML = '';
  for (const g of GOODS) {
    const price = sim.priceOf(planet, g.id);
    const sell = sim.sellPrice(planet, g.id);
    const have = p.cargo[g.id] || 0;
    const mul = price / g.base;
    const cls = mul < 0.75 ? 'cheap' : mul > 1.35 ? 'dear' : '';
    const tr = document.createElement('tr');
    tr.innerHTML =
      `<td>${g.name}</td>` +
      `<td class="price ${cls}" title="Продажа: ${sell}">${price} ⨯</td>` +
      `<td>${have}</td>` +
      `<td></td>`;
    const td = tr.lastChild;
    const mk = (label, clsName, fn, dis) => {
      const b = document.createElement('button');
      b.textContent = label; b.className = clsName; b.disabled = !!dis;
      b.onclick = fn; td.appendChild(b);
    };
    mk('+1', 'buy', () => act(() => sim.buyGood(world, planet, g.id, 1), 'buy'),
      p.credits < price || sim.cargoUsed(p) >= p.cargoMax);
    mk('+5', 'buy', () => act(() => sim.buyGood(world, planet, g.id, 5), 'buy'),
      p.credits < price || sim.cargoUsed(p) >= p.cargoMax);
    mk('−1', 'sell', () => act(() => sim.sellGood(world, planet, g.id, 1), 'sell'), have < 1);
    mk('−все', 'sell', () => act(() => sim.sellGood(world, planet, g.id, have), 'sell'), have < 1);
    tb.appendChild(tr);
  }

  // Сервис
  const svc = $('services');
  svc.innerHTML = '';
  const fuelNeed = Math.ceil(p.maxFuel - p.fuel);
  const hullNeed = Math.ceil(p.maxHull - p.hull);
  const mkSvc = (label, fn, dis) => {
    const b = document.createElement('button');
    b.innerHTML = label; b.disabled = !!dis; b.onclick = fn;
    svc.appendChild(b);
  };
  mkSvc(`Заправка (${fuelNeed} ед · ${fuelNeed * CFG.economy.fuelPrice} ⨯)`,
    () => act(() => sim.refuel(world), 'buy'), fuelNeed <= 0);
  mkSvc(`Ремонт (${hullNeed} ед · ${hullNeed * CFG.economy.repairPrice} ⨯)`,
    () => act(() => sim.repair(world), 'buy'), hullNeed <= 0);

  // Верфь
  const up = $('upgrades');
  up.innerHTML = '';
  for (const u of UPGRADES) {
    const lvl = p[u.id === 'hull' ? 'hullLvl' : u.id === 'cargo' ? 'cargoLvl' : u.id];
    const row = document.createElement('div');
    row.className = 'up';
    const pips = '●'.repeat(lvl) + '○'.repeat(3 - lvl);
    const next = lvl < 3 ? `→ ${u.levels[lvl]} за ${fmt(u.prices[lvl])} ⨯` : 'максимум';
    row.innerHTML = `<span>${u.name} <span class="pips">${pips}</span></span>`;
    const b = document.createElement('button');
    b.textContent = lvl < 3 ? next : '— установлено —';
    b.disabled = lvl >= 3 || p.credits < u.prices[lvl];
    b.onclick = () => act(() => sim.buyUpgrade(world, u), 'upgrade');
    row.appendChild(b);
    up.appendChild(row);
  }
}
