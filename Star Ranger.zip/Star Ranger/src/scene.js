// —— Точка входа: цикл, состояния, события → звук/тосты, сохранения ——

import { createWorld, updateWorld } from './game/sim.js';
import { render, renderMinimap, camera, updateCamera } from './game/render.js';
import { input } from './game/input.js';
import { sfx } from './game/audio.js';
import * as ui from './game/ui.js';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const mmap = document.getElementById('minimap');
const mctx = mmap.getContext('2d');

let W = 0, H = 0, DPR = 1;
function resize() {
  DPR = Math.min(devicePixelRatio || 1, 2);
  W = innerWidth; H = innerHeight;
  canvas.width = W * DPR; canvas.height = H * DPR;
  canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  mmap.width = 170 * DPR; mmap.height = 170 * DPR;
  mmap.style.width = '170px'; mmap.style.height = '170px';
  mctx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
addEventListener('resize', resize);
resize();

// ——— Сохранения (localStorage, защищённо) ———
const SAVE_KEY = 'sr_save_v1';
function loadSave() {
  try {
    const s = JSON.parse(localStorage.getItem(SAVE_KEY) || '{}');
    return { best: Number.isFinite(s.best) ? s.best : 0, wins: Number.isFinite(s.wins) ? s.wins : 0 };
  } catch { return { best: 0, wins: 0 }; }
}
function persistSave() {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch { /* приватный режим — молча */ }
}
const save = loadSave();
ui.fillBestLine(save);

// ——— Состояния ———
// title → play ⇄ pause / dock → gameover | victory
let state = 'title';
let world = null;
let thrusting = false;

function newGame() {
  world = createWorld();
  camera.x = world.player.x; camera.y = world.player.y;
  state = 'play';
  ui.showScreen(null);
  ui.updateHUD(world);
  sfx.unlock();
  ui.toast('Добро пожаловать в систему, рейнджер!');
}

function gameOver() {
  state = 'gameover';
  if (world.player.earned > save.best) { save.best = world.player.earned; persistSave(); }
  ui.fillStats('over-stats', world);
  ui.fillBestLine(save);
  ui.showScreen('gameover');
  sfx.bigExplosion();
}

// Адмирал повержен — игра не кончается: цикл засчитан, пираты вернутся злее
function completeCycle() {
  const p = world.player;
  save.wins++;
  if (p.earned > save.best) save.best = p.earned;
  persistSave();
  ui.fillBestLine(save);
  world.cycle++;
  world.bossSpawned = false;
  world.bossDefeated = false;
  p.hull = p.maxHull;                 // флот ремонтирует
  p.fuel = p.maxFuel;                 // …и заправляет за пройденный цикл
  sfx.victory();
  ui.toast(`Цикл ${world.cycle - 1} пройден! Корабль отремонтирован и заправлен.`);
  ui.toast(`Цикл ${world.cycle}: пираты вернутся крепче…`, 'warn');
}

// ——— События мира → звук и тосты ———
function drainEvents() {
  for (const e of world.events) {
    switch (e.type) {
      case 'shoot': sfx.shoot(); break;
      case 'enemyShoot': sfx.enemyShoot(); break;
      case 'hit': sfx.hit(); break;
      case 'hullHit': sfx.hullHit(); break;
      case 'rockDown': sfx.explosion(); break;
      case 'pirateDown': sfx.explosion(); ui.toast(`Пират уничтожен! Награда ${e.bounty} ⨯`); break;
      case 'bossDown': sfx.bigExplosion(); break;
      case 'pirate': ui.toast('Пират вышел на перехват!', 'bad'); break;
      case 'boss': sfx.bossHorn(); ui.toast('⚠ АДМИРАЛ КРЭГ В СИСТЕМЕ!', 'bad'); break;
      case 'loot': ui.toast(`Трофей: ${e.good} ×${e.qty}`); break;
      case 'market': ui.toast('Биржа обновила цены', ''); break;
      case 'radiation': ui.toast('Радиация! Корпус плавится!', 'warn'); break;
    }
  }
  world.events.length = 0;
}

// ——— Глобальные клавиши состояний ———
function handleStateKeys() {
  if (input.wasPressed('KeyM')) {
    const m = sfx.toggleMute();
    ui.toast(m ? 'Звук выключен' : 'Звук включён');
  }

  if (state === 'title') {
    if (input.wasPressed('Space')) newGame();
  } else if (state === 'play') {
    if (input.wasPressed('Escape')) { state = 'pause'; ui.showScreen('pause'); }
    else if (input.wasPressed('KeyE') && world.nearPlanet) {
      state = 'dock';
      sfx.dock();
      ui.setDockPrompt(null);
      ui.openTrade(world, world.nearPlanet, () => ui.updateHUD(world));
      ui.showScreen('trade');
    }
  } else if (state === 'pause') {
    if (input.wasPressed('Escape')) { state = 'play'; ui.showScreen(null); }
    else if (input.wasPressed('KeyR')) newGame();
  } else if (state === 'dock') {
    if (input.wasPressed('KeyE') || input.wasPressed('Escape')) {
      state = 'play';
      ui.showScreen(null);
      // Отброс от планеты, чтобы не зациклить стыковку
      const p = world.player, pl = world.nearPlanet;
      if (pl) {
        const d = Math.hypot(p.x - pl.x, p.y - pl.y) || 1;
        p.vx = (p.x - pl.x) / d * 60; p.vy = (p.y - pl.y) / d * 60;
      }
    }
  } else if (state === 'gameover') {
    if (input.wasPressed('KeyR')) newGame();
  }
}

document.getElementById('leave-dock').onclick = () => {
  if (state === 'dock') { state = 'play'; ui.showScreen(null); }
};

// ——— Цикл с фиксированным шагом ———
const STEP = 1 / 60;
let acc = 0, last = performance.now();

function frame(now) {
  let dt = Math.min((now - last) / 1000, 0.1);
  last = now;

  handleStateKeys();

  if (state === 'play') {
    acc += dt;
    while (acc >= STEP) {
      acc -= STEP;
      thrusting = input.thrust() && world.player.fuel > 0;
      updateWorld(world, STEP, input);
      drainEvents();
    }
    updateCamera(camera, world.player, dt);

    if (world.player.hull <= 0) gameOver();
    else if (world.bossDefeated) completeCycle();
  }

  if (world) {
    render(ctx, world, W, H, thrusting && state === 'play');
    if (state !== 'title') {
      renderMinimap(mctx, world);
      ui.updateHUD(world);
      ui.setDockPrompt(state === 'play' ? world.nearPlanet : null);
    }
  } else {
    ctx.fillStyle = '#04060d';
    ctx.fillRect(0, 0, W, H);
  }

  input.endFrame();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// ——— Хуки для проверки/скриншотов ———
window.__gameProbe = () => world && ({
  state,
  x: world.player.x, y: world.player.y, angle: world.player.angle,
  hull: world.player.hull, fuel: world.player.fuel,
  credits: world.player.credits, kills: world.player.kills,
  pirates: world.pirates.length, boss: world.bossSpawned,
  cam: { x: camera.x, y: camera.y },
  planets: world.planets.map((pl) => ({ n: pl.name, x: Math.round(pl.x), y: Math.round(pl.y) })),
  t: Math.round(world.t),
});
window.__seek = () => {};   // игра интерактивна; стоп-кадр делается паузой
window.__SCENE_READY__ = true;
