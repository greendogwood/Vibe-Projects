# Credits

## Спрайты

**Tiny Swords** — автор [Pixel Frog](https://pixelfrog-assets.itch.io/tiny-swords)

Лицензия: [CC0 (public domain)](https://creativecommons.org/publicdomain/zero/1.0/) —
свободное использование, включая коммерческое, без указания авторства.

Файлы спрайтов взяты из репозитория [endlessm/threadbare](https://github.com/endlessm/threadbare)
(каталог `assets/third_party/tiny-swords`), где размещена CC0-версия пака.

Использованы: юниты (крестьянин, воин, лучник, гоблин с факелом, гоблин-динамитчик),
здания (замок, дом, башня), деревья, рудник, снаряды, эффекты, тайлы земли.
