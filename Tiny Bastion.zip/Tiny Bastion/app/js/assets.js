/* ===== Tiny Bastion — загрузка и нарезка спрайтов ===== */
'use strict';

const Assets = (() => {
  const B = 'assets/sprites/';
  const paths = {
    // юниты игрока (синие)
    pawnBlue:    B + 'Factions/Knights/Troops/Pawn/Blue/Pawn_Blue.png',
    warriorBlue: B + 'Factions/Knights/Troops/Warrior/Blue/Warrior_Blue.png',
    archerBlue:  B + 'Factions/Knights/Troops/Archer/Blue/Archer_Blue.png',
    arrow:       B + 'Factions/Knights/Troops/Archer/Arrow/Arrow.png',
    dead:        B + 'Factions/Knights/Troops/Dead/Dead.png',
    // враги (красные гоблины)
    torchRed:    B + 'Factions/Goblins/Troops/Torch/Red/Torch_Red.png',
    tntRed:      B + 'Factions/Goblins/Troops/TNT/Red/TNT_Red.png',
    dynamite:    B + 'Factions/Goblins/Troops/TNT/Dynamite/Dynamite.png',
    // здания игрока
    castle:      B + 'Factions/Knights/Buildings/Castle/Castle_Blue.png',
    castleCon:   B + 'Factions/Knights/Buildings/Castle/Castle_Construction.png',
    castleDes:   B + 'Factions/Knights/Buildings/Castle/Castle_Destroyed.png',
    house:       B + 'Factions/Knights/Buildings/House/House_Blue.png',
    houseCon:    B + 'Factions/Knights/Buildings/House/House_Construction.png',
    houseDes:    B + 'Factions/Knights/Buildings/House/House_Destroyed.png',
    tower:       B + 'Factions/Knights/Buildings/Tower/Tower_Blue.png',
    towerCon:    B + 'Factions/Knights/Buildings/Tower/Tower_Construction.png',
    towerDes:    B + 'Factions/Knights/Buildings/Tower/Tower_Destroyed.png',
    // лагерь гоблинов
    gobHouse:    B + 'Factions/Goblins/Buildings/Wood_House/Goblin_House.png',
    gobTower:    B + 'Factions/Goblins/Buildings/Wood_Tower/Wood_Tower_Red.png',
    // природа
    tree:        B + 'Resources/Trees/Tree.png',
    goldmine:    B + 'Resources/Gold Mine/GoldMine_Active.png',
    // земля и вода
    tilemap:     B + 'Terrain/Ground/Tilemap_Flat.png',
    water:       B + 'Terrain/Water/Water.png',
    // эффекты
    fire:        B + 'Effects/Fire/Fire.png',
    explosion:   B + 'Effects/Explosion/Explosions.png',
    // декорации
    deco04:      B + 'Deco/04.png',  // камень малый
    deco06:      B + 'Deco/06.png',  // камень большой
    deco07:      B + 'Deco/07.png',  // куст малый
    deco09:      B + 'Deco/09.png',  // куст большой
    deco11:      B + 'Deco/11.png',  // растение
    deco14:      B + 'Deco/14.png',  // кость
    deco16:      B + 'Deco/16.png',  // знак с черепом
  };

  const img = {};
  let ready = false;

  function load() {
    const jobs = Object.entries(paths).map(([k, src]) => new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => { img[k] = im; res(); };
      im.onerror = () => rej(new Error('Не удалось загрузить ' + src));
      im.src = src;
    }));
    return Promise.all(jobs).then(() => { ready = true; });
  }

  // Отрисовка кадра из спрайт-листа.
  // fw/fh — размер кадра; frame — индекс кадра в строке; row — строка;
  // flip — зеркально по X. Якорь — центр низа кадра (cx,cy) в координатах кадра.
  function drawFrame(ctx, key, fw, fh, row, frame, x, y, opts = {}) {
    const im = img[key];
    if (!im) return;
    const flip = opts.flip || false;
    const scale = opts.scale || 1;
    const ax = (opts.anchorX !== undefined ? opts.anchorX : fw / 2);
    const ay = (opts.anchorY !== undefined ? opts.anchorY : fh * 0.78);
    const dw = fw * scale, dh = fh * scale;
    const sx = frame * fw, sy = row * fh;
    ctx.save();
    ctx.translate(x, y);
    if (flip) ctx.scale(-1, 1);
    ctx.drawImage(im, sx, sy, fw, fh, -ax * scale, -ay * scale, dw, dh);
    ctx.restore();
  }

  // Статичный спрайт (здание), якорь — центр низа
  function drawImage(ctx, key, x, y, opts = {}) {
    const im = img[key];
    if (!im) return;
    const scale = opts.scale || 1;
    const ax = (opts.anchorX !== undefined ? opts.anchorX : im.width / 2);
    const ay = (opts.anchorY !== undefined ? opts.anchorY : im.height);
    ctx.save();
    if (opts.alpha !== undefined) ctx.globalAlpha = opts.alpha;
    if (opts.flip) { ctx.translate(x, y); ctx.scale(-1, 1); ctx.drawImage(im, -ax * scale, -ay * scale, im.width * scale, im.height * scale); }
    else ctx.drawImage(im, x - ax * scale, y - ay * scale, im.width * scale, im.height * scale);
    ctx.restore();
  }

  // Поворотный спрайт (снаряды): вращение вокруг центра
  function drawRotated(ctx, key, sx, sy, sw, sh, x, y, angle, scale = 1) {
    const im = img[key];
    if (!im) return;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.drawImage(im, sx, sy, sw, sh, -sw * scale / 2, -sh * scale / 2, sw * scale, sh * scale);
    ctx.restore();
  }

  return { img, load, drawFrame, drawImage, drawRotated, get ready() { return ready; } };
})();
