/* ===== Tiny Bastion — звук (WebAudio, синтез) ===== */
'use strict';

const Sound = (() => {
  let ctx = null;
  let master = null;
  let musicGain = null;
  let muted = false;
  let musicTimer = null;

  function ensure() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.55;
    master.connect(ctx.destination);
    musicGain = ctx.createGain();
    musicGain.gain.value = 0.16;
    musicGain.connect(master);
  }

  function resume() {
    ensure();
    if (ctx && ctx.state === 'suspended') ctx.resume();
  }

  function setMuted(m) {
    muted = m;
    if (master) master.gain.value = m ? 0 : 0.55;
    try { localStorage.setItem(SAVE_KEY + '-mute', m ? '1' : '0'); } catch (e) {}
  }

  function loadMute() {
    try { muted = localStorage.getItem(SAVE_KEY + '-mute') === '1'; } catch (e) {}
    return muted;
  }

  function env(g, t0, a, peak, d, sustain = 0) {
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(peak, t0 + a);
    g.gain.exponentialRampToValueAtTime(Math.max(sustain, 0.0001), t0 + a + d);
  }

  function tone(freq, dur, type = 'sine', vol = 0.3, slideTo = null, delay = 0) {
    if (!ctx || muted) return;
    const t0 = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(slideTo, 1), t0 + dur);
    env(g, t0, 0.008, vol, dur);
    o.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  function noise(dur, vol = 0.3, freq = 1000, q = 1, type = 'bandpass', delay = 0, slideTo = null) {
    if (!ctx || muted) return;
    const t0 = ctx.currentTime + delay;
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = type; f.frequency.setValueAtTime(freq, t0); f.Q.value = q;
    if (slideTo) f.frequency.exponentialRampToValueAtTime(Math.max(slideTo, 20), t0 + dur);
    const g = ctx.createGain();
    env(g, t0, 0.005, vol, dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t0); src.stop(t0 + dur + 0.05);
  }

  const S = {
    click()      { tone(660, 0.06, 'square', 0.12, 520); },
    error()      { tone(180, 0.18, 'sawtooth', 0.16, 120); },
    place()      { noise(0.16, 0.3, 300, 1, 'lowpass'); tone(90, 0.15, 'sine', 0.3, 60); },
    buildDone()  { tone(520, 0.12, 'triangle', 0.2); tone(780, 0.2, 'triangle', 0.2, null, 0.1); },
    chop()       { noise(0.09, 0.35, 500, 2, 'bandpass'); tone(140, 0.07, 'triangle', 0.15, 90); },
    mine()       { tone(1900, 0.07, 'triangle', 0.12, 1200); noise(0.05, 0.12, 3000, 3); },
    deposit()    { tone(880, 0.07, 'sine', 0.16); tone(1320, 0.1, 'sine', 0.16, null, 0.07); },
    train()      { tone(392, 0.12, 'triangle', 0.14); tone(523, 0.18, 'triangle', 0.14, null, 0.1); },
    swing()      { noise(0.12, 0.2, 1800, 1, 'bandpass', 0, 300); },
    hit()        { noise(0.08, 0.28, 350, 1, 'lowpass'); tone(120, 0.08, 'sine', 0.22, 70); },
    bow()        { tone(700, 0.09, 'triangle', 0.18, 240); },
    arrowHit()   { tone(300, 0.05, 'square', 0.1, 180); },
    fuse()       { noise(0.5, 0.1, 5000, 2, 'highpass'); },
    explosion()  { noise(0.55, 0.55, 400, 0.7, 'lowpass', 0, 60); tone(70, 0.5, 'sine', 0.5, 38); },
    collapse()   { noise(0.7, 0.4, 220, 0.8, 'lowpass', 0, 50); tone(55, 0.6, 'sine', 0.4, 30); },
    waveHorn()   { tone(196, 0.35, 'sawtooth', 0.22); tone(147, 0.5, 'sawtooth', 0.22, null, 0.3); },
    select()     { tone(500, 0.05, 'sine', 0.1); },
    order()      { tone(620, 0.06, 'sine', 0.12, 700); },
    victory() {
      [523, 659, 784, 1046, 784, 1046].forEach((f, i) => tone(f, 0.28, 'triangle', 0.22, null, i * 0.16));
    },
    defeat() {
      [220, 196, 165, 110].forEach((f, i) => tone(f, 0.55, 'sawtooth', 0.18, f * 0.92, i * 0.4));
    },
  };

  // Простая генеративная музыка: дорийский лад, пиццикато + бас
  const SCALE = [146.83, 164.81, 174.61, 196.0, 220.0, 246.94, 261.63, 293.66]; // D dorian
  let musicStep = 0;
  function musicTick() {
    if (muted || !ctx) return;
    const t = musicStep;
    if (t % 4 === 0) {
      const bass = SCALE[[0, 0, 3, 4][Math.floor(t / 4) % 4]] / 2;
      toneAt(musicGain, bass, 0.5, 'triangle', 0.5);
    }
    if (Math.random() < 0.72) {
      const n = SCALE[Math.floor(Math.random() * SCALE.length)] * (Math.random() < 0.25 ? 2 : 1);
      toneAt(musicGain, n, 0.22, 'triangle', 0.3);
    }
    if (t % 8 === 6) toneAt(musicGain, SCALE[4] * 2, 0.14, 'sine', 0.12);
    musicStep++;
  }
  function toneAt(dest, freq, dur, type, vol) {
    if (!ctx) return;
    const t0 = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type; o.frequency.value = freq;
    env(g, t0, 0.01, vol, dur);
    o.connect(g); g.connect(dest);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }
  function startMusic() {
    ensure();
    if (!ctx || musicTimer) return;
    musicTimer = setInterval(musicTick, 300);
  }
  function stopMusic() {
    if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
  }

  return {
    resume, setMuted, loadMute, startMusic, stopMusic,
    get muted() { return muted; },
    play(name) { const f = S[name]; if (f) { resume(); f(); } },
  };
})();
