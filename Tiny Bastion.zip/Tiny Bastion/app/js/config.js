/* ===== Tiny Bastion — конфигурация ===== */
'use strict';

const CFG = {
  TILE: 64,
  MAP_W: 44,          // тайлов по X
  MAP_H: 28,          // тайлов по Y
  FPS_ANIM: 10,       // базовый fps анимаций спрайтов

  START_GOLD: 550,
  START_WOOD: 400,

  FOOD_PER_CASTLE: 10,
  FOOD_PER_HOUSE: 6,

  FIRST_WAVE_DELAY: 75,   // секунд на отстройку до 1-й волны
  WAVE_INTERVAL: 55,      // секунд между волнами
  WAVE_WARN: 6,           // предупреждение за N секунд
  TOTAL_WAVES: 10,

  CAM_SPEED: 620,         // px/сек
  EDGE_PAN: 14,           // px от края для панорамирования

  BUILD_MAX_QUEUE: 5,

  REPAIR_RATE: 30,        // hp/сек при ремонте здания крестьянином
  REPAIR_COST_MUL: 0.35,  // полный ремонт стоит долю от цены постройки
};

// Описание юнитов игрока
const UNITS = {
  pawn: {
    name: 'Крестьянин',
    desc: 'Рубит лес, копает золото, строит и чинит здания. Почти не воин.',
    hp: 40, dmg: 3, range: 30, atkRate: 1.0, speed: 92,
    cost: { gold: 50, wood: 0 }, food: 1, trainTime: 11,
    carryMax: 10, gatherTime: 1.2,
  },
  warrior: {
    name: 'Воин',
    desc: 'Мечник ближнего боя. Держит строй и рубит гоблинов.',
    hp: 170, dmg: 14, range: 34, atkRate: 1.0, speed: 82,
    cost: { gold: 120, wood: 20 }, food: 2, trainTime: 17,
  },
  archer: {
    name: 'Лучник',
    desc: 'Бьёт издалека. Хрупкий — берегите его.',
    hp: 70, dmg: 11, range: 250, atkRate: 1.25, speed: 88,
    cost: { gold: 100, wood: 30 }, food: 2, trainTime: 15,
    projectileSpeed: 520,
  },
};

// Вражеские юниты
const ENEMIES = {
  torch: {
    name: 'Гоблин с факелом',
    hp: 70, dmg: 10, range: 32, atkRate: 0.9, speed: 72,
    aggroR: 110, score: 1,
  },
  tnt: {
    name: 'Гоблин-подрывник',
    hp: 95, dmg: 34, range: 210, atkRate: 2.4, speed: 55,
    aggroR: 90, score: 2,
    aoe: 80, deathAoe: 60, deathDmg: 22,
    projectileSpeed: 300,
  },
};

// Здания
const BUILDINGS = {
  castle: {
    name: 'Замок', desc: 'Сердце крепости. Обучает всех юнитов. Падёт — поражение.',
    hp: 2500, w: 5, h: 4, food: CFG.FOOD_PER_CASTLE,
    spriteW: 320, spriteH: 256,
  },
  house: {
    name: 'Дом', desc: '+6 к припасам. Крыша над головой для войска.',
    hp: 300, w: 2, h: 2, food: CFG.FOOD_PER_HOUSE,
    cost: { gold: 20, wood: 80 }, buildTime: 14,
    spriteW: 128, spriteH: 192,
  },
  tower: {
    name: 'Башня', desc: 'Сама стреляет по врагам в радиусе 4,5 клеток.',
    hp: 420, w: 2, h: 2,
    dmg: 14, range: 290, atkRate: 1.0, projectileSpeed: 560,
    cost: { gold: 150, wood: 100 }, buildTime: 22,
    spriteW: 128, spriteH: 256,
  },
};

// Волны: состав (torch / tnt)
const WAVE_TABLE = [
  { torch: 4,  tnt: 0  },
  { torch: 6,  tnt: 0  },
  { torch: 7,  tnt: 2  },
  { torch: 9,  tnt: 3  },
  { torch: 12, tnt: 4  },
  { torch: 14, tnt: 6  },
  { torch: 17, tnt: 8  },
  { torch: 21, tnt: 10 },
  { torch: 25, tnt: 12 },
  { torch: 30, tnt: 16 },
];

const SAVE_KEY = 'tiny-bastion-v1';
