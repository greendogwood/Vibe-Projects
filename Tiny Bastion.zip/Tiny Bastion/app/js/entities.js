/* ===== Tiny Bastion — сущности: юниты, здания, снаряды ===== */
'use strict';

// Раскадровка спрайтов (строки листов 192x192)
const SPRITES = {
  pawn: {
    img: 'pawnBlue', fw: 192, fh: 192, anchorY: 150,
    anims: {
      idle:  { row: 0, n: 6, fps: 8 },
      walk:  { row: 1, n: 6, fps: 10 },
      work:  { row: 2, n: 6, fps: 10 },
      work2: { row: 3, n: 6, fps: 10 },
      carry: { row: 4, n: 6, fps: 9 },
    },
  },
  warrior: {
    img: 'warriorBlue', fw: 192, fh: 192, anchorY: 150,
    anims: {
      idle:     { row: 0, n: 6, fps: 8 },
      walk:     { row: 1, n: 6, fps: 11 },
      attack:   { row: 2, n: 6, fps: 12 },
      attack2:  { row: 4, n: 6, fps: 12 },
      attackUp: { row: 6, n: 6, fps: 12 },
    },
  },
  archer: {
    img: 'archerBlue', fw: 192, fh: 192, anchorY: 150,
    anims: {
      idle:       { row: 0, n: 8, fps: 8 },
      walk:       { row: 1, n: 8, fps: 11 },
      attack:     { row: 3, n: 8, fps: 12 },
      attackDown: { row: 5, n: 8, fps: 12 },
      attackUp:   { row: 2, n: 8, fps: 12 },
    },
  },
  torch: {
    img: 'torchRed', fw: 192, fh: 192, anchorY: 150,
    anims: {
      idle:     { row: 0, n: 7, fps: 8 },
      walk:     { row: 1, n: 7, fps: 11 },
      attack:   { row: 2, n: 6, fps: 12 },
      attack2:  { row: 3, n: 6, fps: 12 },
      attackUp: { row: 4, n: 6, fps: 12 },
    },
  },
  tnt: {
    img: 'tntRed', fw: 192, fh: 192, anchorY: 150,
    anims: {
      idle:   { row: 0, n: 7, fps: 8 },
      walk:   { row: 1, n: 7, fps: 11 },
      attack: { row: 2, n: 7, fps: 10 },
    },
  },
};

let __uid = 1;

class Unit {
  constructor(kind, x, y, faction) {
    this.id = __uid++;
    this.kind = kind;
    this.faction = faction; // 'player' | 'enemy'
    const st = faction === 'player' ? UNITS[kind] : ENEMIES[kind];
    this.st = st;
    this.x = x; this.y = y;
    this.hp = st.hp; this.maxHp = st.hp;
    this.alive = true;
    this.radius = 14;

    this.order = null;         // {type,...}
    this.state = 'idle';
    this.guardX = x; this.guardY = y;

    this.anim = 'idle';
    this.animT = Math.random();
    this.flip = false;
    this.attackTimer = 0;
    this.flash = 0;
    this.harvestSnd = 0;

    this.target = null;        // юнит/здание для атаки
    this.node = null;          // ресурсная нода (дерево/шахта)
    this.carry = 0;
    this.workTimer = 0;

    this.flowOff = Math.random() * Math.PI * 2; // лёгкий разброс по flow-field

    this.path = null;          // маршрут обхода (A*)
    this.pathI = 0;
    this.stuckT = 0;
    this._mtInit = false;
  }

  get isMilitary() { return this.kind !== 'pawn'; }
  get centerX() { return this.x; }
  get centerY() { return this.y - 16; }

  setAnim(name) {
    if (this.anim !== name) { this.anim = name; this.animT = 0; }
  }

  issue(order) {
    this.order = order;
    this.target = null;
    if (order.type === 'move') { this.state = 'move'; }
    else if (order.type === 'gather') { this.state = 'gather_go'; this.node = order.node; }
    else if (order.type === 'build') { this.state = 'build_go'; this.buildTarget = order.building; }
    else if (order.type === 'repair') { this.state = 'repair_go'; this.buildTarget = order.building; }
    else if (order.type === 'attack') { this.state = 'attack_chase'; this.target = order.target; }
    else if (order.type === 'attackmove') { this.state = 'attackmove'; }
    this.guardX = order.x !== undefined ? order.x : this.x;
    this.guardY = order.y !== undefined ? order.y : this.y;
  }

  update(dt, world) {
    if (!this.alive) return;
    this.flash = Math.max(0, this.flash - dt);
    this.attackTimer = Math.max(0, this.attackTimer - dt);
    const spr = SPRITES[this.kind];
    const an = spr.anims[this.anim] || spr.anims.idle;
    this.animT += dt * an.fps / an.n;

    if (this.faction === 'enemy') this.updateEnemy(dt, world);
    else this.updatePlayer(dt, world);

    this.separate(dt, world);
  }

  // ---------- движение ----------
  moveToward(tx, ty, dt, world, speedMul = 1) {
    // смена цели — сбрасываем маршрут
    if (!this._mtInit || Math.hypot(tx - this._mtx, ty - this._mty) > 24) {
      this._mtInit = true; this._mtx = tx; this._mty = ty;
      this.path = null; this.stuckT = 0; this._sx = this.x; this._sy = this.y;
    }
    if (Math.hypot(tx - this.x, ty - this.y) < 6) { this.path = null; return true; }
    // идём по маршруту обхода, если построен
    let gx = tx, gy = ty;
    if (this.path) {
      const wp = this.path[this.pathI];
      if (!wp) this.path = null;
      else if (Math.hypot(wp.x - this.x, wp.y - this.y) < 12) this.pathI++;
      else { gx = wp.x; gy = wp.y; }
    }
    const dx = gx - this.x, dy = gy - this.y;
    const d = Math.hypot(dx, dy);
    if (d >= 2) {
      const sp = this.st.speed * speedMul;
      let vx = (dx / d) * sp * dt, vy = (dy / d) * sp * dt;
      if (Math.abs(vx) > Math.abs(dx)) vx = dx;
      if (Math.abs(vy) > Math.abs(dy)) vy = dy;
      this.tryMove(vx, vy);
      this.flip = dx < -1;
    }
    // застряли по прямой — строим обход
    this.stuckT += dt;
    if (this.stuckT >= 0.6) {
      const moved = Math.hypot(this.x - this._sx, this.y - this._sy);
      if (moved < 4 && !this.path) {
        const p = Path.find(this.x, this.y, tx, ty);
        if (p && p.length) { this.path = p; this.pathI = 0; }
      }
      this._sx = this.x; this._sy = this.y; this.stuckT = 0;
    }
    return false;
  }

  tryMove(vx, vy) {
    const T = CFG.TILE;
    const r = this.radius * 0.7;
    // число точек круга, попадающих в препятствие
    const pen = (x, y) => {
      const pts = [[x + r, y], [x - r, y], [x, y + r], [x, y - r]];
      let n = 0;
      for (const [px, py] of pts) {
        const tx = Math.floor(px / T), ty = Math.floor(py / T);
        if (!GameMap.inBounds(tx, ty) || GameMap.grid[GameMap.idx(tx, ty)] !== 0) n++;
      }
      return n;
    };
    const cur = pen(this.x, this.y);
    if (cur > 0) {
      // круг уже задевает препятствие (например, после расталкивания):
      // разрешаем любое движение, которое не увеличивает проникновение —
      // иначе юнит навсегда замирает на границе тайла
      if (pen(this.x + vx, this.y + vy) <= cur) { this.x += vx; this.y += vy; return; }
      if (pen(this.x + vx, this.y) <= cur) { this.x += vx; return; }
      if (pen(this.x, this.y + vy) <= cur) { this.y += vy; return; }
      return;
    }
    if (!pen(this.x + vx, this.y + vy)) { this.x += vx; this.y += vy; return; }
    if (!pen(this.x + vx, this.y)) { this.x += vx; return; }
    if (!pen(this.x, this.y + vy)) { this.y += vy; return; }
  }

  separate(dt, world) {
    // расталкивание юнитов
    for (const o of world.units) {
      if (o === this || !o.alive) continue;
      const dx = this.x - o.x, dy = this.y - o.y;
      const d2 = dx * dx + dy * dy;
      const min = (this.radius + o.radius) * 0.9;
      if (d2 > 0.01 && d2 < min * min) {
        const d = Math.sqrt(d2);
        const push = (min - d) * 0.5;
        const nx = dx / d, ny = dy / d;
        const nxPos = this.x + nx * push, nyPos = this.y + ny * push;
        // не запихиваем юнита в непроходимый тайл
        const tx = Math.floor(nxPos / CFG.TILE), ty = Math.floor(nyPos / CFG.TILE);
        if (GameMap.inBounds(tx, ty) && GameMap.grid[GameMap.idx(tx, ty)] === 0) {
          this.x = nxPos; this.y = nyPos;
        }
      }
    }
  }

  // ---------- логика игрока ----------
  updatePlayer(dt, world) {
    switch (this.state) {
      case 'idle': {
        this.setAnim(this.carry > 0 ? 'carry' : 'idle');
        if (this.isMilitary) {
          const e = world.nearestEnemy(this.x, this.y, this.st.range + 60);
          if (e) { this.state = 'attack_chase'; this.target = e; break; }
          // вернуться на позицию охраны
          if (Math.hypot(this.guardX - this.x, this.guardY - this.y) > 12) {
            this.state = 'move'; this.order = { type: 'move', x: this.guardX, y: this.guardY };
          }
        }
        break;
      }
      case 'move': {
        this.setAnim('walk');
        const arrived = this.moveToward(this.order.x, this.order.y, dt, world);
        if (arrived) { this.state = 'idle'; this.guardX = this.x; this.guardY = this.y; }
        break;
      }
      case 'attackmove': {
        const e = world.nearestEnemy(this.x, this.y, 220);
        if (e) { this.state = 'attack_chase'; this.target = e; break; }
        this.setAnim('walk');
        if (this.moveToward(this.order.x, this.order.y, dt, world)) {
          this.state = 'idle';
        }
        break;
      }
      case 'attack_chase': {
        const t = this.target;
        if (!t || !t.alive) {
          this.target = null;
          // продолжить attackmove или встать
          if (this.order && this.order.type === 'attackmove') {
            this.state = 'attackmove';
          } else this.state = 'idle';
          break;
        }
        const d = Math.hypot(t.centerX - this.x, t.centerY - this.y);
        const reach = this.st.range + (t.radius || 20);
        if (d <= reach) {
          // атакуем
          const up = t.centerY < this.y - 20;
          let a = 'attack';
          if (SPRITES[this.kind].anims.attackUp && up) a = 'attackUp';
          else if (SPRITES[this.kind].anims.attackDown && !up) a = 'attackDown';
          else if (SPRITES[this.kind].anims.attack2 && Math.random() < 0.5) a = 'attack2';
          if (!SPRITES[this.kind].anims[a]) a = 'attack';
          this.setAnim(a);
          this.flip = t.centerX < this.x;
          if (this.attackTimer <= 0) {
            this.attackTimer = this.st.atkRate;
            if (this.kind === 'archer') {
              world.spawnProjectile('arrow', this, t, this.st.dmg);
              Sound.play('bow');
            } else {
              Sound.play('swing');
              t.takeDamage(this.st.dmg, world, this);
              world.spawnHit(t.centerX, t.centerY);
              Sound.play('hit');
            }
          }
        } else {
          this.setAnim('walk');
          // воин преследует, лучник догоняет до дальности
          this.moveToward(t.centerX, t.centerY, dt, world);
          // слишком далеко от охраняемой точки — вернуться
          if (this.order && this.order.type !== 'attack' && this.order.type !== 'attackmove') {
            if (Math.hypot(this.guardX - this.x, this.guardY - this.y) > 420) {
              this.target = null; this.state = 'move';
              this.order = { type: 'move', x: this.guardX, y: this.guardY };
            }
          }
        }
        break;
      }
      case 'gather_go': {
        const node = this.node;
        if (!node || node.depleted()) { this.findNewNode(world); if (!this.node) { this.state = 'idle'; break; } }
        const spot = this.node.spotFor(this);
        this.setAnim(this.carry > 0 ? 'carry' : 'walk');
        if (this.moveToward(spot.x, spot.y, dt, world)) {
          this.state = 'gather_work'; this.workTimer = 0;
        }
        break;
      }
      case 'gather_work': {
        const node = this.node;
        if (!node || node.depleted()) { this.findNewNode(world); this.state = this.node ? 'gather_go' : 'idle'; break; }
        this.setAnim('work');
        this.flip = node.centerX() < this.x;
        this.workTimer += dt;
        this.harvestSnd -= dt;
        if (this.harvestSnd <= 0) { Sound.play(node.kind === 'tree' ? 'chop' : 'mine'); this.harvestSnd = 0.55; }
        if (this.workTimer >= this.st.gatherTime) {
          this.workTimer = 0;
          const got = node.take(this.st.carryMax);
          this.carry = got;
          if (this.carry > 0 || node.depleted()) {
            this.state = 'gather_return';
          }
        }
        break;
      }
      case 'gather_return': {
        const drop = world.castle;
        if (!drop || !drop.alive) { this.state = 'idle'; break; }
        const spot = drop.dropoffSpot(this);
        this.setAnim('carry');
        if (this.moveToward(spot.x, spot.y, dt, world)) {
          if (this.carry > 0) {
            world.deposit(this.carryKind(), this.carry);
            this.carry = 0;
            Sound.play('deposit');
          }
          if (this.node && !this.node.depleted()) this.state = 'gather_go';
          else { this.findNewNode(world); this.state = this.node ? 'gather_go' : 'idle'; }
        }
        break;
      }
      case 'build_go': {
        const b = this.buildTarget;
        if (!b || !b.alive || b.done) { this.state = 'idle'; break; }
        const spot = b.buildSpot(this);
        this.setAnim('walk');
        if (this.moveToward(spot.x, spot.y, dt, world)) {
          this.state = 'build'; this.workTimer = 0;
        }
        break;
      }
      case 'repair_go': {
        const b = this.buildTarget;
        if (!b || !b.alive || !b.done || b.hp >= b.maxHp) { this.state = 'idle'; break; }
        const spot = b.buildSpot(this);
        this.setAnim('walk');
        if (this.moveToward(spot.x, spot.y, dt, world)) {
          this.state = 'repair'; this.workTimer = 0;
        }
        break;
      }
      case 'repair': {
        const b = this.buildTarget;
        if (!b || !b.alive || b.hp >= b.maxHp) { this.state = 'idle'; break; }
        this.setAnim('work');
        this.flip = b.centerX < this.x;
        // стоимость: доля от цены постройки за полный цикл ремонта
        const cost = b.st.cost || { gold: 250, wood: 150 };
        const need = CFG.REPAIR_RATE * dt;
        const gCost = (cost.gold || 0) * CFG.REPAIR_COST_MUL / b.maxHp * need;
        const wCost = (cost.wood || 0) * CFG.REPAIR_COST_MUL / b.maxHp * need;
        if (world.gold >= gCost && world.wood >= wCost) {
          world.gold -= gCost; world.wood -= wCost;
          b.hp = Math.min(b.maxHp, b.hp + need);
          this.harvestSnd -= dt;
          if (this.harvestSnd <= 0) { Sound.play('chop'); this.harvestSnd = 0.7; }
          if (b.hp >= b.maxHp) {
            this.state = 'idle';
            world.alert(b.st.name + ': ремонт завершён', 'good');
            Sound.play('buildDone');
          }
        } else {
          this.harvestSnd -= dt;
          if (this.harvestSnd <= 0) { world.alert('Нет ресурсов для ремонта!', 'bad'); this.harvestSnd = 3; }
        }
        break;
      }
      case 'build': {
        const b = this.buildTarget;
        if (!b || !b.alive || b.done) { this.state = 'idle'; break; }
        this.setAnim('work');
        this.flip = b.centerX < this.x;
        this.harvestSnd -= dt;
        if (this.harvestSnd <= 0) { Sound.play('chop'); this.harvestSnd = 0.7; }
        b.progress += dt / b.st.buildTime;
        b.hp = Math.min(b.maxHp, b.st.hp * (0.1 + 0.9 * b.progress));
        if (b.progress >= 1) {
          b.complete(world);
          this.state = 'idle';
        }
        break;
      }
    }
  }

  carryKind() { return this.node ? this.node.kind : 'tree'; }

  findNewNode(world) {
    this.node = world.nearestNode(this.x, this.y, this.node ? this.node.kind : null);
  }

  // ---------- логика врага ----------
  updateEnemy(dt, world) {
    // цель в ближнем бою?
    if (this.target && (!this.target.alive)) this.target = null;

    if (!this.target) {
      // агро на юнитов игрока
      const u = world.nearestPlayerUnit(this.x, this.y, this.st.aggroR);
      if (u) this.target = u;
    }

    if (this.kind === 'tnt') {
      // подрывник: цель — здание в радиусе броска
      if (!this.target || !this.target.isBuilding) {
        const b = world.preferredBuilding(this.x, this.y, this.st.range + 40);
        if (b) this.target = b;
      }
    } else {
      // факел: если рядом здание — бить его
      if (!this.target) {
        const b = world.nearestBuilding(this.x, this.y, 90);
        if (b) this.target = b;
      }
    }

    if (this.target) {
      const t = this.target;
      const d = Math.hypot(t.centerX - this.x, t.centerY - this.y);
      const reach = this.st.range + (t.radius || 26);
      if (d <= reach) {
        const up = t.centerY < this.y - 20;
        let a = 'attack';
        if (SPRITES[this.kind].anims.attackUp && up) a = 'attackUp';
        else if (SPRITES[this.kind].anims.attack2 && Math.random() < 0.5) a = 'attack2';
        if (!SPRITES[this.kind].anims[a]) a = 'attack';
        this.setAnim(a);
        this.flip = t.centerX < this.x;
        if (this.attackTimer <= 0) {
          this.attackTimer = this.st.atkRate;
          if (this.kind === 'tnt') {
            world.spawnProjectile('dynamite', this, t, this.st.dmg);
            Sound.play('fuse');
          } else {
            Sound.play('swing');
            t.takeDamage(this.st.dmg, world, this);
            world.spawnHit(t.centerX, t.centerY);
          }
        }
        return;
      }
      // двигаемся к цели
      this.setAnim('walk');
      if (t.isBuilding) {
        this.moveToward(t.centerX, t.centerY, dt, world);
      } else {
        this.moveToward(t.x, t.y, dt, world);
      }
      return;
    }

    // нет цели — идём по flow-field к замку
    const f = FlowField.dirAt(this.x, this.y);
    if (f) {
      this.setAnim('walk');
      // небольшой индивидуальный разброс
      const wob = Math.sin(world.time * 0.7 + this.flowOff) * 0.35;
      const ang = Math.atan2(f.y, f.x) + wob;
      const sp = this.st.speed * dt;
      this.tryMove(Math.cos(ang) * sp, Math.sin(ang) * sp);
      this.flip = Math.cos(ang) < 0;

      // если впереди здание — атаковать его
      const aheadTx = Math.floor((this.x + Math.cos(ang) * 40) / CFG.TILE);
      const aheadTy = Math.floor((this.y + Math.sin(ang) * 40) / CFG.TILE);
      if (GameMap.inBounds(aheadTx, aheadTy) && GameMap.grid[GameMap.idx(aheadTx, aheadTy)] === 2) {
        const b = world.buildingAtTile(aheadTx, aheadTy);
        if (b && b.alive) this.target = b;
      }
    } else {
      // вне поля — сперва к ближайшей клетке с проложенным путём
      const wp = FlowField.nearestReachable(this.x, this.y);
      if (wp) {
        this.setAnim('walk');
        this.moveToward(wp.x, wp.y, dt, world);
      } else {
        const c = world.castle;
        if (c) { this.setAnim('walk'); this.moveToward(c.centerX, c.centerY, dt, world); }
        else this.setAnim('idle');
      }
    }
  }

  takeDamage(dmg, world, from) {
    if (!this.alive) return;
    this.hp -= dmg;
    this.flash = 0.12;
    if (this.hp <= 0) {
      this.alive = false;
      world.onUnitDied(this);
    }
  }

  draw(ctx, cam, time) {
    const spr = SPRITES[this.kind];
    const an = spr.anims[this.anim] || spr.anims.idle;
    const frame = Math.floor(this.animT * an.n) % an.n;
    const x = this.x - cam.x, y = this.y - cam.y;

    // тень
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath();
    ctx.ellipse(x, y - 3, 16, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    if (this.flash > 0) ctx.filter = 'brightness(2.2)';
    Assets.drawFrame(ctx, spr.img, spr.fw, spr.fh, an.row, frame, x, y, {
      flip: this.flip, anchorY: spr.anchorY,
    });
    ctx.filter = 'none';

    // полоса здоровья
    if (this.hp < this.maxHp) {
      const w = 34, pct = Math.max(0, this.hp / this.maxHp);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(x - w / 2 - 1, y - 62, w + 2, 6);
      ctx.fillStyle = this.faction === 'player' ? (pct > 0.35 ? '#57a34a' : '#d4883a') : '#d44a3a';
      ctx.fillRect(x - w / 2, y - 61, w * pct, 4);
    }
  }
}

class Building {
  constructor(kind, tx, ty, faction, instant) {
    this.id = __uid++;
    this.kind = kind;
    this.faction = faction;
    this.st = BUILDINGS[kind];
    this.tx = tx; this.ty = ty;
    this.w = this.st.w; this.h = this.st.h;
    this.isBuilding = true;
    this.alive = true;
    this.radius = Math.max(this.w, this.h) * CFG.TILE * 0.45;
    this.centerX = (tx + this.w / 2) * CFG.TILE;
    this.centerY = (ty + this.h / 2) * CFG.TILE;
    this.maxHp = this.st.hp;
    this.done = !!instant;
    this.progress = instant ? 1 : 0;
    this.hp = instant ? this.st.hp : this.st.hp * 0.1;
    this.flash = 0;
    this.attackTimer = 0;
    this.queue = [];        // очередь обучения (только замок)
    this.trainT = 0;
    this.rallyX = this.centerX;
    this.rallyY = this.centerY + this.h * CFG.TILE / 2 + CFG.TILE;
    this.target = null;
    this.fireT = Math.random() * 10;
  }

  complete(world) {
    this.done = true;
    this.progress = 1;
    this.hp = this.maxHp;
    world.recalcFood();
    Sound.play('buildDone');
    world.alert(this.st.name + ' построен', 'good');
  }

  dropoffSpot(unit) {
    // ближайшая свободная точка на периметре
    return this.perimeterSpot(unit);
  }
  buildSpot(unit) { return this.perimeterSpot(unit); }
  perimeterSpot(unit) {
    const T = CFG.TILE;
    const left = this.tx * T, right = (this.tx + this.w) * T;
    const top = this.ty * T, bottom = (this.ty + this.h) * T;
    const spots = [];
    for (let x = left; x < right; x += T) {
      spots.push({ x: x + T / 2, y: bottom + T * 0.4 });
      spots.push({ x: x + T / 2, y: top - T * 0.4 });
    }
    for (let y = top; y < bottom; y += T) {
      spots.push({ x: left - T * 0.4, y: y + T / 2 });
      spots.push({ x: right + T * 0.4, y: y + T / 2 });
    }
    let best = null, bd = Infinity;
    for (const s of spots) {
      const tx = Math.floor(s.x / T), ty = Math.floor(s.y / T);
      if (!GameMap.inBounds(tx, ty)) continue;
      if (GameMap.grid[GameMap.idx(tx, ty)] !== 0) continue;
      const d = (s.x - unit.x) ** 2 + (s.y - unit.y) ** 2;
      if (d < bd) { bd = d; best = s; }
    }
    return best || { x: this.centerX, y: bottom + T };
  }

  update(dt, world) {
    if (!this.alive) return;
    this.flash = Math.max(0, this.flash - dt);
    this.attackTimer = Math.max(0, this.attackTimer - dt);
    if (!this.done) return;

    // башня стреляет
    if (this.kind === 'tower') {
      if (!this.target || !this.target.alive || Math.hypot(this.target.x - this.centerX, this.target.y - this.centerY) > this.st.range) {
        this.target = world.nearestEnemy(this.centerX, this.centerY, this.st.range);
      }
      if (this.target && this.attackTimer <= 0) {
        this.attackTimer = this.st.atkRate;
        world.spawnProjectile('arrow', this, this.target, this.st.dmg);
        Sound.play('bow');
      }
    }

    // замок обучает
    if (this.kind === 'castle' && this.queue.length > 0) {
      this.trainT += dt;
      const cur = UNITS[this.queue[0]];
      if (this.trainT >= cur.trainTime) {
        this.trainT = 0;
        const kind = this.queue.shift();
        world.spawnTrainedUnit(kind, this);
      }
    }
  }

  takeDamage(dmg, world, from) {
    if (!this.alive) return;
    this.hp -= dmg;
    this.flash = 0.12;
    if (this.hp <= 0) {
      this.alive = false;
      world.onBuildingDestroyed(this);
    }
  }

  draw(ctx, cam, time) {
    const x = this.centerX - cam.x;
    const bottomY = (this.ty + this.h) * CFG.TILE - cam.y + 6;

    // тень
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.ellipse(x, bottomY - 8, this.w * CFG.TILE * 0.42, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    let key = this.kind;
    if (!this.done) key = this.kind + 'Con';
    else if (!this.alive) key = this.kind + 'Des';

    if (this.flash > 0) ctx.filter = 'brightness(2.2)';
    Assets.drawImage(ctx, key, x, bottomY, {});
    ctx.filter = 'none';

    // прогресс стройки
    if (!this.done) {
      const w = this.w * CFG.TILE * 0.8;
      ctx.fillStyle = 'rgba(0,0,0,0.65)';
      ctx.fillRect(x - w / 2 - 1, bottomY - this.st.spriteH - 14, w + 2, 8);
      ctx.fillStyle = '#d4a03a';
      ctx.fillRect(x - w / 2, bottomY - this.st.spriteH - 13, w * this.progress, 6);
    }

    // очаг пожара при сильном уроне
    if (this.alive && this.done && this.hp < this.maxHp * 0.35) {
      const fr = Math.floor((time * 10 + this.fireT) % 7);
      Assets.drawFrame(ctx, 'fire', 128, 128, 0, fr, x, bottomY - this.st.spriteH * 0.45, { anchorY: 90 });
    }

    // полоса здоровья
    if (this.alive && this.hp < this.maxHp) {
      const w = this.w * CFG.TILE * 0.7, pct = Math.max(0, this.hp / this.maxHp);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(x - w / 2 - 1, bottomY - this.st.spriteH - (this.done ? 6 : 26), w + 2, 6);
      ctx.fillStyle = pct > 0.35 ? '#57a34a' : '#d4883a';
      ctx.fillRect(x - w / 2, bottomY - this.st.spriteH - (this.done ? 5 : 25), w * pct, 4);
    }
  }
}

// Снаряды
class Projectile {
  constructor(kind, from, target, dmg) {
    this.id = __uid++;
    this.kind = kind; // 'arrow' | 'dynamite'
    this.from = from;
    this.target = target;
    this.dmg = dmg;
    this.x = from.centerX !== undefined ? from.centerX : from.x;
    this.y = from.centerY !== undefined ? from.centerY : from.y;
    if (!from.isBuilding) this.y -= 30; else this.y -= from.st.spriteH * 0.7;
    this.alive = true;
    this.t = 0;
    this.startX = this.x; this.startY = this.y;
    this.tx = target.centerX !== undefined ? target.centerX : target.x;
    this.ty = target.centerY !== undefined ? target.centerY : target.y;
    const d = Math.max(40, Math.hypot(this.tx - this.x, this.ty - this.y));
    this.flightTime = d / (kind === 'arrow' ? (from.st.projectileSpeed || 520) : ENEMIES.tnt.projectileSpeed);
    if (kind === 'dynamite') this.flightTime = Math.max(0.7, this.flightTime);
  }

  update(dt, world) {
    if (!this.alive) return;
    this.t += dt;
    const k = Math.min(1, this.t / this.flightTime);
    if (this.kind === 'arrow') {
      // самонаведение
      const t = this.target;
      if (t && t.alive) { this.tx = t.centerX !== undefined ? t.centerX : t.x; this.ty = t.centerY !== undefined ? t.centerY : t.y; }
      const dx = this.tx - this.x, dy = this.ty - this.y;
      const d = Math.hypot(dx, dy);
      const sp = 560 * dt;
      if (d < Math.max(18, sp)) {
        this.alive = false;
        if (t && t.alive) {
          t.takeDamage(this.dmg, world, this.from);
          world.spawnHit(this.tx, this.ty);
          Sound.play('arrowHit');
        }
        return;
      }
      this.x += (dx / d) * sp; this.y += (dy / d) * sp;
      this.angle = Math.atan2(dy, dx);
    } else {
      // динамит — баллистика к точке
      const t = this.target;
      if (t && t.alive && this.t < this.flightTime * 0.5) {
        this.tx = t.centerX !== undefined ? t.centerX : t.x;
        this.ty = t.centerY !== undefined ? t.centerY : t.y;
      }
      this.x = this.startX + (this.tx - this.startX) * k;
      this.y = this.startY + (this.ty - this.startY) * k;
      this.arc = Math.sin(k * Math.PI) * 60;
      if (k >= 1) {
        this.alive = false;
        world.explode(this.tx, this.ty, ENEMIES.tnt.aoe, this.dmg, 'enemy');
      }
    }
  }

  draw(ctx, cam, time) {
    const x = this.x - cam.x, y = this.y - cam.y - (this.arc || 0);
    if (this.kind === 'arrow') {
      Assets.drawRotated(ctx, 'arrow', 0, 0, 64, 64, x, y, this.angle || 0, 1);
    } else {
      const fr = Math.floor(time * 12) % 6;
      Assets.drawFrame(ctx, 'dynamite', 64, 64, 0, fr, x, y, { anchorY: 32 });
    }
  }
}

// Ресурсные ноды (обёртки над деревьями/шахтами)
class TreeNode {
  constructor(tree) { this.kind = 'tree'; this.tree = tree; }
  get amount() { return this.tree.wood; }
  depleted() { return this.tree.wood <= 0; }
  take(n) { const g = Math.min(n, this.tree.wood); this.tree.wood -= g; return g; }
  centerX() { return this.tree.tx * CFG.TILE + CFG.TILE / 2; }
  centerY() { return this.tree.ty * CFG.TILE + CFG.TILE / 2; }
  spotFor(unit) {
    const T = CFG.TILE;
    const cx = this.centerX(), cy = this.centerY();
    const ang = Math.atan2(unit.y - cy, unit.x - cx);
    return { x: cx + Math.cos(ang) * T * 0.75, y: cy + Math.sin(ang) * T * 0.75 };
  }
}

class MineNode {
  constructor(mine) { this.kind = 'mine'; this.mine = mine; }
  get amount() { return this.mine.gold; }
  depleted() { return this.mine.gold <= 0; }
  take(n) { const g = Math.min(n, this.mine.gold); this.mine.gold -= g; return g; }
  centerX() { return (this.mine.tx + 1.5) * CFG.TILE; }
  centerY() { return (this.mine.ty + 1) * CFG.TILE; }
  spotFor(unit) {
    const T = CFG.TILE;
    const cx = this.centerX();
    return { x: cx + (unit.x > cx ? T : -T), y: (this.mine.ty + 2) * T + T * 0.3 };
  }
}
