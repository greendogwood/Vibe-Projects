/* ===== Tiny Bastion — flow-field (BFS от периметра цели) ===== */
'use strict';

const FlowField = (() => {
  const W = CFG.MAP_W, H = CFG.MAP_H;
  const dist = new Int32Array(W * H);
  // направление движения из клетки (по градиенту к цели)
  const dirX = new Int8Array(W * H);
  const dirY = new Int8Array(W * H);
  let target = null;   // здание-цель
  let dirty = true;

  const idx = (x, y) => y * W + x;

  function markDirty() { dirty = true; }

  // семена: свободные клетки по периметру здания
  function seedsFor(b) {
    const seeds = [];
    for (let x = b.tx - 1; x <= b.tx + b.w; x++) {
      for (const y of [b.ty - 1, b.ty + b.h]) {
        if (GameMap.inBounds(x, y) && GameMap.grid[idx(x, y)] === 0) seeds.push(x, y);
      }
    }
    for (let y = b.ty; y < b.ty + b.h; y++) {
      for (const x of [b.tx - 1, b.tx + b.w]) {
        if (GameMap.inBounds(x, y) && GameMap.grid[idx(x, y)] === 0) seeds.push(x, y);
      }
    }
    return seeds;
  }

  function compute() {
    dist.fill(-1);
    if (!target || !target.alive) { dirty = false; return; }
    const qx = new Int32Array(W * H);
    const qy = new Int32Array(W * H);
    let head = 0, tail = 0;
    const seeds = seedsFor(target);
    for (let i = 0; i < seeds.length; i += 2) {
      const si = idx(seeds[i], seeds[i + 1]);
      if (dist[si] === 0) continue;
      dist[si] = 0;
      qx[tail] = seeds[i]; qy[tail] = seeds[i + 1]; tail++;
    }
    while (head < tail) {
      const cx = qx[head], cy = qy[head]; head++;
      const d = dist[idx(cx, cy)];
      const nb = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (const [dx, dy] of nb) {
        const nx = cx + dx, ny = cy + dy;
        if (!GameMap.inBounds(nx, ny)) continue;
        const ni = idx(nx, ny);
        if (dist[ni] !== -1) continue;
        if (GameMap.grid[ni] !== 0) continue; // препятствия блокируют (вода тоже)
        dist[ni] = d + 1;
        qx[tail] = nx; qy[tail] = ny; tail++;
      }
    }
    // направления: идём в соседа с минимальной дистанцией (8 направлений)
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = idx(x, y);
        if (dist[i] <= 0) { dirX[i] = 0; dirY[i] = 0; continue; }
        let best = dist[i], bx = 0, by = 0;
        const nb = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
        for (const [dx, dy] of nb) {
          const nx = x + dx, ny = y + dy;
          if (!GameMap.inBounds(nx, ny)) continue;
          const nd = dist[idx(nx, ny)];
          if (nd < 0 || nd >= best) continue;
          // диагонали: не резать углы
          if (dx !== 0 && dy !== 0) {
            if (GameMap.grid[idx(x + dx, y)] !== 0 || GameMap.grid[idx(x, y + dy)] !== 0) continue;
          }
          best = nd; bx = dx; by = dy;
        }
        if (bx === 0 && by === 0) { dirX[i] = 0; dirY[i] = 0; }
        else {
          const len = Math.hypot(bx, by);
          dirX[i] = Math.round((bx / len) * 127);
          dirY[i] = Math.round((by / len) * 127);
        }
      }
    }
    dirty = false;
  }

  function ensure() { if (dirty) compute(); }

  function setTarget(building) {
    target = building;
    dirty = true;
    compute();
  }

  // направление в точке мира (px)
  function dirAt(wx, wy) {
    const tx = Math.floor(wx / CFG.TILE), ty = Math.floor(wy / CFG.TILE);
    if (!GameMap.inBounds(tx, ty)) return null;
    const i = idx(tx, ty);
    if (dirX[i] === 0 && dirY[i] === 0) return null;
    return { x: dirX[i] / 127, y: dirY[i] / 127, d: dist[i] };
  }

  // ближайшая клетка с проложенным путём (страховка от «карманов»)
  function nearestReachable(wx, wy) {
    const T = CFG.TILE;
    const tx0 = Math.floor(wx / T), ty0 = Math.floor(wy / T);
    for (let r = 1; r < 18; r++) {
      let best = null, bd = Infinity;
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
          const nx = tx0 + dx, ny = ty0 + dy;
          if (!GameMap.inBounds(nx, ny)) continue;
          const i = idx(nx, ny);
          if (dist[i] <= 0) continue;
          if (dirX[i] === 0 && dirY[i] === 0) continue;
          const d = dx * dx + dy * dy;
          if (d < bd) { bd = d; best = { x: (nx + 0.5) * T, y: (ny + 0.5) * T }; }
        }
      }
      if (best) return best;
    }
    return null;
  }

  return { dirAt, setTarget, markDirty, ensure, nearestReachable, get dist() { return dist; }, idx };
})();
