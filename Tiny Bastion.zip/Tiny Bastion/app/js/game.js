/* ===== Tiny Bastion — мир и игровой цикл ===== */
'use strict';

class World {
  constructor() {
    this.units = [];
    this.buildings = [];
    this.projectiles = [];
    this.effects = [];
    this.ruins = [];
    this.nodes = new Map();   // ref -> TreeNode/MineNode
    this.selection = [];
    this.time = 0;
    this.gold = CFG.START_GOLD;
    this.wood = CFG.START_WOOD;
    this.foodUsed = 0;
    this.foodMax = 0;
    this.castle = null;
    this.waves = new WaveManager(this);
    this.cam = { x: 0, y: 0, w: 1280, h: 720 };
    this.shake = 0;
    this.shakeMag = 0;
    this.attackMoveArmed = false;
    this.over = false;
    this.stats = { kills: 0, built: 0, trained: 0, gatheredG: 0, gatheredW: 0 };
  }

  // ---------- инициализация ----------
  setup() {
    const T = CFG.TILE;
    // замок 5x4
    const cx = 8, cy = 12;
    this.castle = new Building('castle', cx, cy, 'player', true);
    this.buildings.push(this.castle);
    this.markBuildingTiles(this.castle, 2);

    // стартовый дом
    const house = new Building('house', cx - 3, cy - 4, 'player', true);
    this.buildings.push(house);
    this.markBuildingTiles(house, 2);

    // крестьяне
    for (let i = 0; i < 4; i++) {
      const u = new Unit('pawn', (cx + 1 + i * 0.8) * T, (cy + 5.2) * T, 'player');
      this.units.push(u);
      this.foodUsed += UNITS.pawn.food;
    }
    // воин для первой обороны
    const w = new Unit('warrior', (cx + 4) * T, (cy + 5.4) * T, 'player');
    this.units.push(w);
    this.foodUsed += UNITS.warrior.food;

    this.recalcFood();
    FlowField.setTarget(this.castle);

    // камера на базу
    this.centerCameraOnCastle();

    // подсказки
    UI.hint('Выделите крестьян рамкой (ЛКМ) и кликните ПКМ по деревьям или руднику — начнётся добыча', 9);
    UI.hint('Нажмите B и поставьте Дом — он даёт +6 припасов для найма войска', 8);
    UI.hint('Кликните по замку и обучите воинов (W) и лучников (E) — гоблины уже близко!', 8);
    UI.hint('Башня (T) стреляет сама. Две-три башни у подступов спасут крепость', 8);
    UI.hint('Крестьянин чинит здания: выделите его и кликните ПКМ по повреждённому зданию', 8);
  }

  centerCameraOnCastle() {
    if (!this.castle) return;
    this.cam.x = Math.max(0, Math.min(this.castle.centerX - this.cam.w / 2, GameMap.W * CFG.TILE - this.cam.w));
    this.cam.y = Math.max(0, Math.min(this.castle.centerY - this.cam.h / 2, GameMap.H * CFG.TILE - this.cam.h));
  }

  // ---------- ресурсы ----------
  canAfford(cost) {
    return this.gold >= (cost.gold || 0) && this.wood >= (cost.wood || 0);
  }
  spend(cost) {
    this.gold -= cost.gold || 0;
    this.wood -= cost.wood || 0;
  }
  deposit(kind, amount) {
    if (kind === 'mine') { this.gold += amount; this.stats.gatheredG += amount; }
    else { this.wood += amount; this.stats.gatheredW += amount; }
  }
  recalcFood() {
    this.foodMax = this.buildings
      .filter(b => b.alive && b.done)
      .reduce((s, b) => s + (b.st.food || 0), 0);
  }

  // ---------- поиск ----------
  nearestEnemy(x, y, range) {
    let best = null, bd = range * range;
    for (const u of this.units) {
      if (!u.alive || u.faction !== 'enemy') continue;
      const d2 = (u.x - x) ** 2 + (u.y - y) ** 2;
      if (d2 < bd) { bd = d2; best = u; }
    }
    return best;
  }
  nearestPlayerUnit(x, y, range) {
    let best = null, bd = range * range;
    for (const u of this.units) {
      if (!u.alive || u.faction !== 'player') continue;
      const d2 = (u.x - x) ** 2 + (u.y - y) ** 2;
      if (d2 < bd) { bd = d2; best = u; }
    }
    return best;
  }
  nearestBuilding(x, y, range) {
    let best = null, bd = range * range;
    for (const b of this.buildings) {
      if (!b.alive || b.faction !== 'player') continue;
      const d2 = (b.centerX - x) ** 2 + (b.centerY - y) ** 2;
      if (d2 < bd) { bd = d2; best = b; }
    }
    return best;
  }
  preferredBuilding(x, y, range) {
    let best = null, bs = -1;
    for (const b of this.buildings) {
      if (!b.alive || b.faction !== 'player') continue;
      const d = Math.hypot(b.centerX - x, b.centerY - y);
      if (d > range) continue;
      const wgt = b.kind === 'castle' ? 3 : b.kind === 'tower' ? 2 : 1;
      const score = wgt / (1 + d * 0.01);
      if (score > bs) { bs = score; best = b; }
    }
    return best;
  }
  buildingAtTile(tx, ty) {
    for (const b of this.buildings) {
      if (!b.alive) continue;
      if (tx >= b.tx && tx < b.tx + b.w && ty >= b.ty && ty < b.ty + b.h) return b;
    }
    return null;
  }
  buildingNear(wx, wy) {
    for (const b of this.buildings) {
      if (!b.alive) continue;
      if (wx >= b.tx * CFG.TILE - 8 && wx <= (b.tx + b.w) * CFG.TILE + 8 &&
          wy >= (b.ty + b.h) * CFG.TILE - b.st.spriteH && wy <= (b.ty + b.h) * CFG.TILE + 8) return b;
    }
    return null;
  }
  enemyAt(wx, wy, r) {
    for (const u of this.units) {
      if (!u.alive || u.faction !== 'enemy') continue;
      if ((u.x - wx) ** 2 + (u.y - 14 - wy) ** 2 < r * r) return u;
    }
    return null;
  }
  enemyCount() {
    let n = 0;
    for (const u of this.units) if (u.alive && u.faction === 'enemy') n++;
    return n;
  }
  playerUnitCount(kind) {
    let n = 0;
    for (const u of this.units) if (u.alive && u.faction === 'player' && (!kind || u.kind === kind)) n++;
    return n;
  }

  nodeFor(ref, isMine) {
    if (!this.nodes.has(ref)) {
      this.nodes.set(ref, isMine ? new MineNode(ref) : new TreeNode(ref));
    }
    return this.nodes.get(ref);
  }

  nodeAt(wx, wy) {
    const tx = Math.floor(wx / CFG.TILE), ty = Math.floor(wy / CFG.TILE);
    const tree = GameMap.treeAt(tx, ty);
    if (tree && tree.wood > 0) return this.nodeFor(tree, false);
    for (const m of GameMap.mines) {
      if (m.gold <= 0) continue;
      if (tx >= m.tx && tx < m.tx + 3 && ty >= m.ty && ty < m.ty + 2) return this.nodeFor(m, true);
    }
    return null;
  }

  nearestNode(x, y, preferKind) {
    const T = CFG.TILE;
    let best = null, bd = Infinity;
    const consider = (node, cx, cy) => {
      const d = (cx - x) ** 2 + (cy - y) ** 2;
      if (d < bd) { bd = d; best = node; }
    };
    if (!preferKind || preferKind === 'tree') {
      for (const t of GameMap.trees) {
        if (t.wood <= 0) continue;
        consider(this.nodeFor(t, false), t.tx * T + T / 2, t.ty * T + T / 2);
      }
    }
    if (!preferKind || preferKind === 'mine') {
      for (const m of GameMap.mines) {
        if (m.gold <= 0) continue;
        consider(this.nodeFor(m, true), (m.tx + 1.5) * T, (m.ty + 1) * T);
      }
    }
    return best;
  }

  // ---------- действия ----------
  select(list) {
    this.selection = list;
    UI.refreshSelection();
  }

  trainUnit(kind) {
    const c = this.castle;
    if (!c || !c.alive || !c.done) { Sound.play('error'); return; }
    const st = UNITS[kind];
    if (c.queue.length >= CFG.BUILD_MAX_QUEUE) { Sound.play('error'); this.alert('Очередь полна', 'bad'); return; }
    if (!this.canAfford(st.cost)) { Sound.play('error'); this.alert('Не хватает ресурсов!', 'bad'); return; }
    if (this.foodUsed + st.food > this.foodMax) {
      Sound.play('error');
      this.alert('Нужно больше припасов — постройте Дом (B)', 'bad');
      return;
    }
    this.spend(st.cost);
    this.foodUsed += st.food;
    c.queue.push(kind);
    Sound.play('train');
    UI.refresh();
    UI.refreshSelection();
  }

  spawnTrainedUnit(kind, castle) {
    const T = CFG.TILE;
    // свободная точка у замка
    const spot = castle.perimeterSpot({ x: castle.centerX, y: castle.centerY + 100 });
    const u = new Unit(kind, spot.x, spot.y, 'player');
    this.units.push(u);
    this.stats.trained++;
    // идти к точке сбора
    u.issue({ type: 'move', x: castle.rallyX, y: castle.rallyY });
    u.guardX = castle.rallyX; u.guardY = castle.rallyY;
    Sound.play('train');
    UI.refresh();
    UI.refreshSelection();
  }

  placeBuilding(kind, tx, ty) {
    const st = BUILDINGS[kind];
    if (!this.canAfford(st.cost)) { Sound.play('error'); return; }
    this.spend(st.cost);
    const b = new Building(kind, tx, ty, 'player', false);
    this.buildings.push(b);
    this.markBuildingTiles(b, 2);
    FlowField.markDirty();
    this.stats.built++;
    Sound.play('place');
    // ближайший свободный крестьянин идёт строить
    let best = null, bd = Infinity;
    for (const u of this.units) {
      if (!u.alive || u.kind !== 'pawn') continue;
      const d = (u.x - b.centerX) ** 2 + (u.y - b.centerY) ** 2;
      if (d < bd) { bd = d; best = u; }
    }
    if (best) best.issue({ type: 'build', building: b });
    this.alert(st.name + ': начата стройка', 'good');
    UI.refresh();
  }

  markBuildingTiles(b, val) {
    for (let y = b.ty; y < b.ty + b.h; y++) {
      for (let x = b.tx; x < b.tx + b.w; x++) {
        GameMap.blockTile(x, y, val);
      }
    }
  }

  spawnEnemy(kind, camp) {
    const T = CFG.TILE;
    // ближайшая свободная клетка к точке лагеря
    let tx = camp.tx, ty = camp.ty;
    if (!GameMap.walkable(tx, ty)) {
      outer: for (let r = 1; r < 5; r++) {
        for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
          if (GameMap.walkable(tx + dx, ty + dy)) { tx += dx; ty += dy; break outer; }
        }
      }
    }
    const x = (tx + Math.random() * 1.6 - 0.3) * T;
    const y = (ty + Math.random() * 1.6 - 0.3) * T;
    const u = new Unit(kind, x, y, 'enemy');
    this.units.push(u);
  }

  // ---------- бой ----------
  spawnProjectile(kind, from, target, dmg) {
    this.projectiles.push(new Projectile(kind, from, target, dmg));
  }

  explode(x, y, aoe, dmg, sourceFaction) {
    this.effects.push({ type: 'explosion', x, y, t: 0, dur: 0.7 });
    this.addShake(0.25, 6);
    Sound.play('explosion');
    // урон по юнитам и зданиям игрока
    for (const u of this.units) {
      if (!u.alive || u.faction === sourceFaction) continue;
      const d = Math.hypot(u.x - x, u.y - y);
      if (d < aoe + u.radius) u.takeDamage(dmg * (u.isMilitary || u.kind !== 'pawn' ? 0.7 : 1), this, null);
    }
    for (const b of this.buildings) {
      if (!b.alive || b.faction === sourceFaction) continue;
      const d = Math.hypot(b.centerX - x, b.centerY - y);
      if (d < aoe + b.radius) b.takeDamage(dmg, this, null);
    }
  }

  spawnHit(x, y) {
    this.effects.push({ type: 'hit', x, y, t: 0, dur: 0.18 });
  }

  spawnOrderMarker(x, y, color) {
    this.effects.push({ type: 'marker', x, y, t: 0, dur: 0.55, color });
  }

  addShake(dur, mag) {
    this.shake = Math.max(this.shake, dur);
    this.shakeMag = Math.max(this.shakeMag, mag);
  }

  onUnitDied(unit) {
    this.effects.push({ type: 'dead', x: unit.x, y: unit.y, t: 0, dur: 1.6 });
    if (unit.faction === 'enemy') {
      this.stats.kills++;
      if (unit.kind === 'tnt') {
        // подрывник взрывается при гибели
        this.explode(unit.x, unit.y, ENEMIES.tnt.deathAoe, ENEMIES.tnt.deathDmg, 'enemy');
      }
    } else {
      this.foodUsed = Math.max(0, this.foodUsed - unit.st.food);
      if (unit.kind === 'pawn') this.alert('Крестьянин погиб!', 'bad');
    }
    UI.refresh();
  }

  onBuildingDestroyed(b) {
    this.markBuildingTiles(b, 0);
    FlowField.markDirty();
    this.recalcFood();
    this.ruins.push({ key: b.kind + 'Des', x: b.centerX, bottomY: (b.ty + b.h) * CFG.TILE + 6, spriteH: b.st.spriteH });
    this.effects.push({ type: 'explosion', x: b.centerX, y: b.centerY, t: 0, dur: 0.8 });
    this.addShake(0.4, 9);
    Sound.play('collapse');
    if (b === this.castle) {
      this.defeat();
    } else {
      this.alert(b.st.name + ' разрушен!', 'bad');
    }
    UI.refresh();
  }

  alert(text, kind) { UI.alert(text, kind); }

  victory() {
    if (this.over) return;
    this.over = true;
    Sound.play('victory');
    Game.end(true);
  }

  defeat() {
    if (this.over) return;
    this.over = true;
    Sound.play('defeat');
    Game.end(false);
  }

  // ---------- обновление ----------
  update(dt) {
    this.time += dt;
    FlowField.ensure(); // пересчёт поля после изменений проходимости
    this.waves.update(dt);
    for (const u of this.units) u.update(dt, this);
    for (const b of this.buildings) b.update(dt, this);
    for (const p of this.projectiles) p.update(dt, this);
    for (const e of this.effects) e.t += dt;
    // чистка
    this.units = this.units.filter(u => u.alive);
    this.projectiles = this.projectiles.filter(p => p.alive);
    this.effects = this.effects.filter(e => e.t < e.dur);
    // обновить выбор (убрать мёртвых)
    const before = this.selection.length;
    this.selection = this.selection.filter(s => s.alive);
    if (this.selection.length !== before) UI.refreshSelection();
    // деревья: исчерпаны -> пень, клетка свободна
    for (const t of GameMap.trees) {
      if (!t.dead && t.wood <= 0) {
        t.dead = true;
        GameMap.blockTile(t.tx, t.ty, 0);
      }
    }
    this.shake = Math.max(0, this.shake - dt);
    if (this.shake <= 0) this.shakeMag = 0;

    Input.updateCamera(dt);
    UI.refresh();
    UI.updateHints(dt);
  }

  // ---------- рендер ----------
  render(ctx) {
    const cam = this.cam;
    let sx = 0, sy = 0;
    if (this.shake > 0) {
      sx = (Math.random() - 0.5) * this.shakeMag;
      sy = (Math.random() - 0.5) * this.shakeMag;
    }
    const vcam = { x: cam.x + sx, y: cam.y + sy, w: cam.w, h: cam.h };

    ctx.fillStyle = '#0d1a0d';
    ctx.fillRect(0, 0, cam.w, cam.h);

    // земля
    ctx.drawImage(GameMap.ground, -vcam.x, -vcam.y);
    GameMap.drawWaterOverlay(ctx, vcam, this.time);

    // руины
    for (const r of this.ruins) {
      Assets.drawImage(ctx, r.key, r.x - vcam.x, r.bottomY - vcam.y, { alpha: 0.85 });
    }

    // лагери гоблинов (декор)
    for (const c of GameMap.camps) {
      const fr = Math.floor(this.time * 6) % 4;
      Assets.drawFrame(ctx, 'gobTower', 128, 192, 0, fr, (c.tx + 0.5) * CFG.TILE - vcam.x, (c.ty + 1.6) * CFG.TILE - vcam.y, { anchorY: 186 });
      Assets.drawImage(ctx, 'gobHouse', (c.tx + 1.8) * CFG.TILE - vcam.x, (c.ty + 2.2) * CFG.TILE - vcam.y, { anchorY: 186 });
    }

    // выделение (под спрайтами)
    for (const s of this.selection) {
      const x = (s.isBuilding ? s.centerX : s.x) - vcam.x;
      const y = (s.isBuilding ? (s.ty + s.h) * CFG.TILE : s.y) - vcam.y;
      ctx.strokeStyle = 'rgba(127, 212, 127, 0.9)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      if (s.isBuilding) ctx.ellipse(x, y - 4, s.w * CFG.TILE * 0.55, 12, 0, 0, Math.PI * 2);
      else ctx.ellipse(x, y - 2, 18, 7, 0, 0, Math.PI * 2);
      ctx.stroke();
    }

    // y-сортировка: деревья, шахты, здания, юниты
    const drawList = [];
    for (const t of GameMap.trees) {
      drawList.push({ y: (t.ty + 1) * CFG.TILE, kind: 'tree', ref: t });
    }
    for (const m of GameMap.mines) {
      drawList.push({ y: (m.ty + 2) * CFG.TILE, kind: 'mine', ref: m });
    }
    for (const b of this.buildings) {
      if (b.alive) drawList.push({ y: (b.ty + b.h) * CFG.TILE, kind: 'building', ref: b });
    }
    for (const u of this.units) {
      drawList.push({ y: u.y, kind: 'unit', ref: u });
    }
    drawList.sort((a, b2) => a.y - b2.y);

    for (const item of drawList) {
      if (item.kind === 'tree') {
        const t = item.ref;
        const x = (t.tx + 0.5) * CFG.TILE - vcam.x;
        const y = (t.ty + 1) * CFG.TILE - vcam.y + 4;
        if (t.dead) {
          Assets.drawFrame(ctx, 'tree', 192, 192, 2, 0, x, y, { anchorY: 176 });
        } else {
          // лёгкое покачивание
          const sway = Math.sin(this.time * 0.8 + t.tx * 2.1 + t.ty) * 0.012;
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(sway);
          Assets.drawFrame(ctx, 'tree', 192, 192, 0, t.variant, 0, 0, { anchorY: 176 });
          ctx.restore();
        }
      } else if (item.kind === 'mine') {
        const m = item.ref;
        const x = (m.tx + 1.5) * CFG.TILE - vcam.x;
        const y = (m.ty + 2) * CFG.TILE - vcam.y + 2;
        Assets.drawImage(ctx, 'goldmine', x, y, { alpha: m.gold > 0 ? 1 : 0.4 });
      } else if (item.kind === 'building') {
        item.ref.draw(ctx, vcam, this.time);
      } else {
        item.ref.draw(ctx, vcam, this.time);
      }
    }

    // снаряды
    for (const p of this.projectiles) p.draw(ctx, vcam, this.time);

    // эффекты
    for (const e of this.effects) {
      const x = e.x - vcam.x, y = e.y - vcam.y;
      if (e.type === 'dead') {
        const total = 10; // 7 кадров ряда 0 + 3 ряда 1
        const f = Math.min(total - 1, Math.floor(e.t / e.dur * total));
        const row = f < 7 ? 0 : 1;
        const col = f < 7 ? f : f - 7 + 4;
        const alpha = e.t > e.dur * 0.7 ? 1 - (e.t - e.dur * 0.7) / (e.dur * 0.3) : 1;
        ctx.globalAlpha = alpha;
        Assets.drawFrame(ctx, 'dead', 128, 128, row, Math.min(col, 6), x, y, { anchorY: 100 });
        ctx.globalAlpha = 1;
      } else if (e.type === 'explosion') {
        const f = Math.min(8, Math.floor(e.t / e.dur * 9));
        Assets.drawFrame(ctx, 'explosion', 192, 192, 0, f, x, y, { anchorY: 120 });
      } else if (e.type === 'hit') {
        const k = e.t / e.dur;
        ctx.fillStyle = 'rgba(255, 230, 120,' + (1 - k) + ')';
        ctx.beginPath();
        ctx.arc(x, y, 4 + k * 10, 0, Math.PI * 2);
        ctx.fill();
      } else if (e.type === 'marker') {
        const k = e.t / e.dur;
        ctx.strokeStyle = e.color;
        ctx.globalAlpha = 1 - k;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(x, y, 6 + k * 22, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }

    // точка сбора замка
    if (this.castle && this.castle.alive && this.selection.includes(this.castle)) {
      const x = this.castle.rallyX - vcam.x, y = this.castle.rallyY - vcam.y;
      ctx.strokeStyle = 'rgba(90, 167, 232, 0.9)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, y - 22); ctx.lineTo(x, y); ctx.stroke();
      ctx.fillStyle = '#5aa7e8';
      ctx.beginPath();
      ctx.moveTo(x, y - 22); ctx.lineTo(x + 14, y - 17); ctx.lineTo(x, y - 12);
      ctx.closePath(); ctx.fill();
    }

    // призрак размещения и рамка выбора
    Input.drawPlacementGhost(ctx, vcam);
    Input.drawDragBox(ctx);

    // виньетка краёв карты
    if (cam.x <= 0) { ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(0, 0, 3, cam.h); }
  }
}

// ===== Состояния игры и цикл =====
const Game = (() => {
  let state = 'loading'; // loading | title | playing | paused | end
  let world = null;
  let canvas = null, ctx = null;
  let last = 0, acc = 0;
  const STEP = 1 / 60;
  let uiTick = 0;

  function initCanvas() {
    canvas = document.getElementById('game');
    ctx = canvas.getContext('2d');
    resize();
    window.addEventListener('resize', resize);
  }

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    if (world) {
      world.cam.w = canvas.width;
      world.cam.h = canvas.height;
    }
  }

  function setScreen(name) {
    for (const id of ['screen-loading', 'screen-title', 'screen-pause', 'screen-end']) {
      document.getElementById(id).classList.toggle('hidden', id !== name);
    }
    if (!name) {
      for (const id of ['screen-loading', 'screen-title', 'screen-pause', 'screen-end']) {
        document.getElementById(id).classList.add('hidden');
      }
    }
  }

  function toTitle() {
    state = 'title';
    UI.hide();
    setScreen('screen-title');
    const best = loadBest();
    document.getElementById('best-stats').textContent =
      best.games > 0
        ? `Игр сыграно: ${best.games} · Побед: ${best.wins} · Лучший результат: волна ${best.bestWave}/10`
        : 'Первая вылазка. Удачи, командир!';
  }

  function newGame() {
    __uid = 1;
    GameMap.generate();
    GameMap.prerender();
    world = new World();
    world.cam.w = canvas.width;
    world.cam.h = canvas.height;
    UI.init(world);
    Input.init(world);
    world.setup();
    UI.show();
    UI.refreshSelection();
    setScreen(null);
    state = 'playing';
    Sound.resume();
    Sound.startMusic();
    const best = loadBest();
    best.games++;
    saveBest(best);
  }

  function togglePause() {
    if (state === 'playing') {
      state = 'paused';
      setScreen('screen-pause');
      Sound.play('click');
    } else if (state === 'paused') {
      state = 'playing';
      setScreen(null);
      Sound.play('click');
    }
  }

  function end(win) {
    state = 'end';
    const best = loadBest();
    best.bestWave = Math.max(best.bestWave, world.waves.wave);
    if (win) best.wins++;
    saveBest(best);

    const title = document.getElementById('end-title');
    const text = document.getElementById('end-text');
    if (win) {
      title.textContent = 'ПОБЕДА!';
      title.classList.remove('defeat');
      text.textContent =
        `Крепость устояла — отбиты все 10 волн!\n` +
        `Убито гоблинов: ${world.stats.kills} · Обучено бойцов: ${world.stats.trained}\n` +
        `Добыто золота: ${world.stats.gatheredG} · древесины: ${world.stats.gatheredW}\n` +
        `Построено зданий: ${world.stats.built}`;
    } else {
      title.textContent = 'КРЕПОСТЬ ПАЛА';
      title.classList.add('defeat');
      text.textContent =
        `Замок разрушен на волне ${world.waves.wave} из 10.\n` +
        `Убито гоблинов: ${world.stats.kills} · Построено зданий: ${world.stats.built}\n` +
        `В следующий раз: больше башен и не жалейте древесины на дома!`;
    }
    setScreen('screen-end');
  }

  function loadBest() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) return Object.assign({ bestWave: 0, wins: 0, games: 0 }, JSON.parse(raw));
    } catch (e) {}
    return { bestWave: 0, wins: 0, games: 0 };
  }
  function saveBest(b) {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(b)); } catch (e) {}
  }

  function loop(ts) {
    requestAnimationFrame(loop);
    if (!last) last = ts;
    let dt = (ts - last) / 1000;
    last = ts;
    if (dt > 0.25) dt = 0.25; // защита от «скачка» при сворачивании

    if (state === 'playing' && world) {
      acc += dt;
      let steps = 0;
      while (acc >= STEP && steps < 6) {
        world.update(STEP);
        acc -= STEP;
        steps++;
      }
      if (steps === 6) acc = 0;
      world.render(ctx);
      // миникарта и кнопки — не каждый кадр
      uiTick += dt;
      if (uiTick > 0.15) {
        uiTick = 0;
        UI.drawMinimap();
        UI.refreshSelection();
      }
    } else if ((state === 'paused' || state === 'end') && world) {
      world.render(ctx);
    }
  }

  function start() {
    initCanvas();
    Assets.load()
      .then(() => { toTitle(); requestAnimationFrame(loop); })
      .catch((err) => {
        document.getElementById('loading-text').textContent = 'Ошибка загрузки: ' + err.message;
      });

    document.getElementById('btn-start').addEventListener('click', () => { Sound.resume(); Sound.play('click'); newGame(); });
    document.getElementById('btn-resume').addEventListener('click', () => togglePause());
    document.getElementById('btn-restart').addEventListener('click', () => { Sound.play('click'); newGame(); });
    document.getElementById('btn-restart2').addEventListener('click', () => { Sound.play('click'); newGame(); });
    document.getElementById('btn-totitle').addEventListener('click', () => { Sound.play('click'); toTitle(); });
    document.getElementById('btn-totitle2').addEventListener('click', () => { Sound.play('click'); toTitle(); });
  }

  return {
    start, newGame, togglePause, toTitle, end,
    get state() { return state; },
    get world() { return world; },
  };
})();
