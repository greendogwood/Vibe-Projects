/* ===== Tiny Bastion — ввод: мышь, клавиатура, камера, размещение ===== */
'use strict';

const Input = (() => {
  const canvas = () => document.getElementById('game');
  let world = null;

  const mouse = { x: -1, y: -1, wx: 0, wy: 0, left: false, right: false, inside: false };
  const drag = { active: false, x0: 0, y0: 0, x1: 0, y1: 0, moved: false };
  const keys = {};
  let placement = null; // {kind}
  let minimapDrag = false;

  function init(w) {
    world = w;
    const cv = canvas();

    cv.addEventListener('contextmenu', (e) => e.preventDefault());

    cv.addEventListener('mousedown', (e) => {
      Sound.resume();
      if (e.button === 0) {
        mouse.left = true;
        drag.active = true;
        drag.moved = false;
        drag.x0 = e.offsetX; drag.y0 = e.offsetY;
        drag.x1 = e.offsetX; drag.y1 = e.offsetY;
      } else if (e.button === 2) {
        mouse.right = true;
        if (placement) { cancelPlacement(); }
        else rightOrder(e);
      }
    });

    window.addEventListener('mousemove', (e) => {
      const r = cv.getBoundingClientRect();
      mouse.x = e.clientX - r.left;
      mouse.y = e.clientY - r.top;
      mouse.inside = true;
      mouse.wx = mouse.x + world.cam.x;
      mouse.wy = mouse.y + world.cam.y;
      if (drag.active) {
        drag.x1 = mouse.x; drag.y1 = mouse.y;
        if (Math.hypot(drag.x1 - drag.x0, drag.y1 - drag.y0) > 8) drag.moved = true;
      }
      updateCursor();
    });

    window.addEventListener('mouseup', (e) => {
      if (e.button === 0) {
        mouse.left = false;
        if (drag.active) {
          if (placement) tryPlace();
          else if (drag.moved) boxSelect();
          else clickSelect(e);
          drag.active = false;
        }
      } else if (e.button === 2) mouse.right = false;
    });

    window.addEventListener('keydown', (e) => {
      if (e.repeat) return;
      const k = e.key.toLowerCase();
      keys[k] = true;
      Sound.resume();

      if (k === 'escape') {
        if (placement) { cancelPlacement(); return; }
        Game.togglePause();
        return;
      }
      if (k === 'p') { Game.togglePause(); return; }
      if (k === 'm') { Sound.setMuted(!Sound.muted); UI.refreshMute(); return; }
      if (k === ' ') { e.preventDefault(); world.centerCameraOnCastle(); return; }
      if (k === 'b') { startPlacement('house'); return; }
      if (k === 't') { startPlacement('tower'); return; }
      if (k === 'q' || k === 'w' || e.key.toLowerCase() === 'e') {
        const kind = { q: 'pawn', w: 'warrior', e: 'archer' }[k];
        const castle = world.selection.find(s => s.isBuilding && s.kind === 'castle' && s.done);
        if (castle && kind) { world.trainUnit(kind); Sound.play('click'); }
      }
      if (k === 'a') {
        // атаковать-двигаться: следующий ПКМ-клик будет attackmove (запасной вариант)
        world.attackMoveArmed = true;
        world.alert('Атаковать-двигаться: кликните ПКМ по точке', 'good');
      }
    });

    window.addEventListener('keyup', (e) => { keys[e.key.toLowerCase()] = false; });
    window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
    document.addEventListener('mouseleave', () => { mouse.inside = false; });
    document.addEventListener('mouseenter', () => { mouse.inside = true; });

    // миникарта
    const mm = document.getElementById('minimap');
    const mmMove = (e) => {
      const r = mm.getBoundingClientRect();
      const p = UI.minimapToWorld(e.clientX - r.left, e.clientY - r.top);
      world.cam.x = clampCamX(p.x - world.cam.w / 2);
      world.cam.y = clampCamY(p.y - world.cam.h / 2);
    };
    mm.addEventListener('mousedown', (e) => { minimapDrag = true; mmMove(e); e.stopPropagation(); });
    window.addEventListener('mousemove', (e) => { if (minimapDrag) mmMove(e); });
    window.addEventListener('mouseup', () => { minimapDrag = false; });
  }

  function clampCamX(x) { return Math.max(0, Math.min(x, GameMap.W * CFG.TILE - world.cam.w)); }
  function clampCamY(y) { return Math.max(0, Math.min(y, GameMap.H * CFG.TILE - world.cam.h)); }

  // ---------- камера ----------
  function updateCamera(dt) {
    const cam = world.cam;
    let dx = 0, dy = 0;
    if (keys['arrowleft']) dx -= 1;
    if (keys['arrowright']) dx += 1;
    if (keys['arrowup']) dy -= 1;
    if (keys['arrowdown']) dy += 1;
    // края экрана (только когда курсор реально внутри окна)
    if (mouse.inside) {
      if (mouse.x >= 0 && mouse.x <= CFG.EDGE_PAN) dx -= 1;
      if (mouse.x >= cam.w - CFG.EDGE_PAN && mouse.x <= cam.w) dx += 1;
      if (mouse.y >= 0 && mouse.y <= CFG.EDGE_PAN) dy -= 1;
      if (mouse.y >= cam.h - CFG.EDGE_PAN && mouse.y <= cam.h) dy += 1;
    }
    if (dx || dy) {
      const len = Math.hypot(dx, dy);
      cam.x = clampCamX(cam.x + (dx / len) * CFG.CAM_SPEED * dt);
      cam.y = clampCamY(cam.y + (dy / len) * CFG.CAM_SPEED * dt);
    }
  }

  // ---------- выбор ----------
  function clickSelect(e) {
    const wx = mouse.wx, wy = mouse.wy;
    // сначала юниты игрока
    let best = null, bd = 28 * 28;
    for (const u of world.units) {
      if (!u.alive || u.faction !== 'player') continue;
      const d2 = (u.x - wx) ** 2 + (u.y - 14 - wy) ** 2;
      if (d2 < bd) { bd = d2; best = u; }
    }
    if (best) {
      world.select([best]);
      Sound.play('select');
      return;
    }
    // здания
    const tx = Math.floor(wx / CFG.TILE), ty = Math.floor(wy / CFG.TILE);
    const b = world.buildingAtTile(tx, ty) || world.buildingNear(wx, wy);
    if (b && b.faction === 'player') {
      world.select([b]);
      Sound.play('select');
      return;
    }
    world.select([]);
  }

  function boxSelect() {
    const x0 = Math.min(drag.x0, drag.x1) + world.cam.x;
    const y0 = Math.min(drag.y0, drag.y1) + world.cam.y;
    const x1 = Math.max(drag.x0, drag.x1) + world.cam.x;
    const y1 = Math.max(drag.y0, drag.y1) + world.cam.y;
    const sel = world.units.filter(u =>
      u.alive && u.faction === 'player' &&
      u.x >= x0 && u.x <= x1 && (u.y - 14) >= y0 && (u.y - 14) <= y1
    );
    world.select(sel);
    if (sel.length) Sound.play('select');
  }

  // ---------- правый клик: приказ ----------
  function rightOrder(e) {
    const wx = mouse.wx, wy = mouse.wy;
    const sel = world.selection.filter(s => !s.isBuilding && s.alive);
    const bsel = world.selection.find(s => s.isBuilding);

    // точка сбора для замка
    if (bsel && bsel.kind === 'castle') {
      bsel.rallyX = wx; bsel.rallyY = wy;
      world.spawnOrderMarker(wx, wy, '#5aa7e8');
      Sound.play('order');
      return;
    }
    if (sel.length === 0) return;

    // цель под курсором: враг?
    const enemy = world.enemyAt(wx, wy, 30);
    if (enemy) {
      for (const u of sel) {
        if (u.isMilitary) u.issue({ type: 'attack', target: enemy });
      }
      world.spawnOrderMarker(wx, wy, '#e05a4e');
      Sound.play('order');
      return;
    }

    // attackmove?
    if (world.attackMoveArmed) {
      world.attackMoveArmed = false;
      for (const u of sel) u.issue({ type: 'attackmove', x: wx, y: wy });
      world.spawnOrderMarker(wx, wy, '#e05a4e');
      Sound.play('order');
      return;
    }

    // ресурсная нода?
    const node = world.nodeAt(wx, wy);
    if (node) {
      let any = false;
      for (const u of sel) {
        if (u.kind === 'pawn') { u.issue({ type: 'gather', node }); any = true; }
        else u.issue({ type: 'move', x: wx, y: wy });
      }
      world.spawnOrderMarker(wx, wy, '#e8c15a');
      Sound.play('order');
      return;
    }

    // недострой или ремонт?
    const tx = Math.floor(wx / CFG.TILE), ty = Math.floor(wy / CFG.TILE);
    const con = world.buildingAtTile(tx, ty);
    if (con && con.faction === 'player' && !con.done) {
      for (const u of sel) {
        if (u.kind === 'pawn') u.issue({ type: 'build', building: con });
        else u.issue({ type: 'move', x: wx, y: wy });
      }
      world.spawnOrderMarker(wx, wy, '#d4a03a');
      Sound.play('order');
      return;
    }
    if (con && con.faction === 'player' && con.done && con.hp < con.maxHp) {
      for (const u of sel) {
        if (u.kind === 'pawn') u.issue({ type: 'repair', building: con });
        else u.issue({ type: 'move', x: wx, y: wy });
      }
      world.spawnOrderMarker(wx, wy, '#5ae8a7');
      Sound.play('order');
      return;
    }

    // просто движение
    // формация: расставим цели небольшой сеткой
    const n = sel.length;
    const cols = Math.ceil(Math.sqrt(n));
    sel.forEach((u, i) => {
      const gx = wx + ((i % cols) - (cols - 1) / 2) * 26;
      const gy = wy + (Math.floor(i / cols) - (Math.ceil(n / cols) - 1) / 2) * 26;
      u.issue({ type: 'move', x: gx, y: gy });
    });
    world.spawnOrderMarker(wx, wy, '#7fd47f');
    Sound.play('order');
  }

  // ---------- размещение зданий ----------
  function startPlacement(kind) {
    const hasPawn = world.selection.some(s => !s.isBuilding && s.kind === 'pawn');
    if (!hasPawn) { Sound.play('error'); return; }
    const st = BUILDINGS[kind];
    if (!world.canAfford(st.cost)) {
      Sound.play('error');
      world.alert('Не хватает ресурсов!', 'bad');
      return;
    }
    placement = { kind };
    Sound.play('click');
  }

  function cancelPlacement() {
    placement = null;
    Sound.play('click');
  }

  function placementTiles() {
    if (!placement) return null;
    const st = BUILDINGS[placement.kind];
    const tx = Math.floor(mouse.wx / CFG.TILE - st.w / 2 + 0.5);
    const ty = Math.floor(mouse.wy / CFG.TILE - st.h / 2 + 0.5);
    return { tx, ty, w: st.w, h: st.h };
  }

  function placementValid() {
    const p = placementTiles();
    if (!p) return false;
    for (let y = p.ty; y < p.ty + p.h; y++) {
      for (let x = p.tx; x < p.tx + p.w; x++) {
        if (!GameMap.inBounds(x, y)) return false;
        if (GameMap.grid[GameMap.idx(x, y)] !== 0) return false;
      }
    }
    // не ближе 6 клеток к лагерю врага
    for (const c of GameMap.camps) {
      if (Math.hypot(c.tx - (p.tx + p.w / 2), c.ty - (p.ty + p.h / 2)) < 6) return false;
    }
    return true;
  }

  function tryPlace() {
    if (!placementValid()) { Sound.play('error'); return; }
    const p = placementTiles();
    world.placeBuilding(placement.kind, p.tx, p.ty);
    placement = null;
  }

  function drawPlacementGhost(ctx, cam) {
    if (!placement) return;
    const p = placementTiles();
    const ok = placementValid();
    const x = p.tx * CFG.TILE - cam.x, y = p.ty * CFG.TILE - cam.y;
    ctx.fillStyle = ok ? 'rgba(90, 220, 90, 0.25)' : 'rgba(220, 70, 60, 0.3)';
    ctx.fillRect(x, y, p.w * CFG.TILE, p.h * CFG.TILE);
    ctx.strokeStyle = ok ? '#5adc5a' : '#dc463c';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, p.w * CFG.TILE, p.h * CFG.TILE);
    Assets.drawImage(ctx, placement.kind, x + p.w * CFG.TILE / 2, y + p.h * CFG.TILE, { alpha: 0.6 });
  }

  function drawDragBox(ctx) {
    if (!drag.active || !drag.moved || placement) return;
    const x = Math.min(drag.x0, drag.x1), y = Math.min(drag.y0, drag.y1);
    const w = Math.abs(drag.x1 - drag.x0), h = Math.abs(drag.y1 - drag.y0);
    ctx.fillStyle = 'rgba(127, 212, 127, 0.12)';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = '#7fd47f';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x, y, w, h);
  }

  function updateCursor() {
    const cv = canvas();
    const enemy = world && world.enemyAt(mouse.wx, mouse.wy, 30);
    cv.classList.toggle('cursor-attack', !!enemy && !placement);
  }

  return {
    init, updateCamera, drawDragBox, drawPlacementGhost,
    startPlacement, cancelPlacement,
    get placement() { return placement; },
    keys, mouse,
  };
})();
