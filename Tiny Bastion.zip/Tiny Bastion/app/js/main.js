/* ===== Tiny Bastion — точка входа ===== */
'use strict';

window.addEventListener('DOMContentLoaded', () => {
  Sound.loadMute();
  Game.start();
});
