/* ===== Tiny Bastion — карта: генерация, проходимость, пререндер земли ===== */
'use strict';

const GameMap = (() => {
  const T = CFG.TILE;
  const W = CFG.MAP_W, H = CFG.MAP_H;

  // сетка проходимости: 0 = свободно, 1 = препятствие (природа), 2 = здание, 3 = вода
  let grid = [];
  // статическая природа: деревья (с запасом дерева), шахты (с золотом), вода, декор
  const trees = [];      // {tx,ty,wood,variant,dead}
  const mines = [];      // {tx,ty,gold}  (3x2 тайла)
  const waterTiles = []; // {tx,ty}
  const decos = [];      // {tx,ty,key,scale}
  const camps = [];      // {tx,ty,dirName} — точки спавна врагов
  let groundCanvas = null;

  const idx = (x, y) => y * W + x;
  const inBounds = (x, y) => x >= 0 && y >= 0 && x < W && y < H;
  const walkable = (x, y) => inBounds(x, y) && grid[idx(x, y)] === 0;

  // --- генерация ---
  function generate() {
    grid = new Array(W * H).fill(0);
    trees.length = 0; mines.length = 0; waterTiles.length = 0; decos.length = 0; camps.length = 0;

    // Вода: озеро справа-центру (направляет атаки гоблинов)
    const lake = [
      [31, 15], [32, 15], [33, 15], [34, 15],
      [30, 16], [31, 16], [32, 16], [33, 16], [34, 16], [35, 16],
      [30, 17], [31, 17], [32, 17], [33, 17], [34, 17], [35, 17],
      [31, 18], [32, 18], [33, 18], [34, 18],
      [32, 19], [33, 19],
    ];
    for (const [x, y] of lake) {
      grid[idx(x, y)] = 3;
      waterTiles.push({ tx: x, ty: y });
    }

    // Деревья: рощи
    const addTree = (x, y, v) => {
      if (!inBounds(x, y) || grid[idx(x, y)] !== 0) return;
      grid[idx(x, y)] = 1;
      trees.push({ tx: x, ty: y, wood: 150, variant: v !== undefined ? v : Math.floor(Math.random() * 4), dead: false });
    };
    // большая роща слева сверху
    for (let y = 2; y <= 6; y++) for (let x = 3; x <= 11; x++) {
      if (Math.random() < 0.82) addTree(x, y);
    }
    // роща слева снизу
    for (let y = 21; y <= 25; y++) for (let x = 4; x <= 13; x++) {
      if (Math.random() < 0.8) addTree(x, y);
    }
    // редкие деревья по центру и справа
    for (let i = 0; i < 26; i++) {
      const x = 16 + Math.floor(Math.random() * 26);
      const y = 2 + Math.floor(Math.random() * 24);
      addTree(x, y);
    }
    // пара деревьев ближе к базе (стартовая древесина)
    addTree(5, 14); addTree(4, 16); addTree(6, 17);

    // Золотые шахты (3x2): одна у базы, вторая дальше
    const addMine = (x, y, gold) => {
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 3; dx++) {
        if (inBounds(x + dx, y + dy)) {
          grid[idx(x + dx, y + dy)] = 1;
          const t = trees.find(tr => tr.tx === x + dx && tr.ty === y + dy);
          if (t) { t.dead = true; t.wood = 0; }
        }
      }
      mines.push({ tx: x, ty: y, gold, maxGold: gold });
    };
    addMine(15, 8, 2500);
    addMine(26, 3, 2500);
    addMine(22, 23, 2500);

    // Лагери гоблинов (правый край)
    camps.push({ tx: 41, ty: 3,  dirName: 'севера' });
    camps.push({ tx: 41, ty: 13, dirName: 'востока' });
    camps.push({ tx: 41, ty: 24, dirName: 'юга' });

    // расчищаем подступы к лагерям от случайных деревьев
    for (const c of camps) {
      for (const t of trees) {
        if (!t.dead && Math.hypot(t.tx - c.tx, t.ty - c.ty) < 3.2) {
          t.dead = true; t.wood = 0;
          grid[idx(t.tx, t.ty)] = 0;
        }
      }
    }

    // Гарантия связности: все свободные клетки должны быть достижимы от замка,
    // иначе враги застрянут в «карманах» из деревьев.
    ensureConnectivity();

    // Декорации (не блокируют)
    const decoKeys = ['deco04', 'deco06', 'deco07', 'deco09', 'deco11', 'deco14'];
    for (let i = 0; i < 40; i++) {
      const x = Math.floor(Math.random() * W);
      const y = Math.floor(Math.random() * H);
      if (grid[idx(x, y)] !== 0) continue;
      if (x < 16 && y > 8 && y < 19) continue; // не мусорить у базы
      decos.push({ tx: x, ty: y, key: decoKeys[Math.floor(Math.random() * decoKeys.length)] });
    }
    // знаки с черепом у лагерей
    for (const c of camps) decos.push({ tx: c.tx - 2, ty: c.ty, key: 'deco16' });
  }

  // --- обход: линия клеток от точки к точке ---
  function blockTile(x, y, val) {
    if (inBounds(x, y)) grid[idx(x, y)] = val;
  }

  // --- пререндер земли ---
  function prerender() {
    groundCanvas = document.createElement('canvas');
    groundCanvas.width = W * T;
    groundCanvas.height = H * T;
    const g = groundCanvas.getContext('2d');

    const tm = Assets.img.tilemap;
    const water = Assets.img.water;

    // базовая трава — бесшовный центральный тайл (1,1), вариации отражениями
    // детерминированный псевдослучайный выбор
    let seed = 1234567;
    const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;

    // заранее готовим 4 отражённых варианта тайла
    const variants = [];
    for (let v = 0; v < 4; v++) {
      const c = document.createElement('canvas');
      c.width = 64; c.height = 64;
      const g2 = c.getContext('2d');
      g2.translate(32, 32);
      g2.scale(v & 1 ? -1 : 1, v & 2 ? -1 : 1);
      g2.drawImage(tm, 64, 64, 64, 64, -32, -32, 64, 64);
      variants.push(c);
    }
    // пучок травы (4,2) — с прозрачным фоном
    const tuft = document.createElement('canvas');
    tuft.width = 64; tuft.height = 64;
    tuft.getContext('2d').drawImage(tm, 256, 128, 64, 64, 0, 0, 64, 64);

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const v = grid[idx(x, y)];
        if (v === 3) {
          g.drawImage(water, x * T, y * T, T, T);
          continue;
        }
        g.drawImage(variants[Math.floor(rnd() * 4)], x * T, y * T);
        if (rnd() < 0.07) g.drawImage(tuft, x * T, y * T);
        // лёгкий шум яркости, чтобы поле не выглядело сеткой
        const n = rnd();
        if (n < 0.28) {
          g.fillStyle = n < 0.14 ? 'rgba(0,40,0,0.06)' : 'rgba(255,255,180,0.05)';
          g.fillRect(x * T, y * T, T, T);
        }
      }
    }

    // песчаная кромка вокруг воды (используем жёлтый автотайл — внутренний тайл)
    g.globalAlpha = 0.85;
    for (const w of waterTiles) {
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (const [dx, dy] of dirs) {
        const nx = w.tx + dx, ny = w.ty + dy;
        if (inBounds(nx, ny) && grid[idx(nx, ny)] === 0) {
          g.drawImage(tm, 384, 64, 64, 64, nx * T, ny * T, T, T);
        }
      }
    }
    g.globalAlpha = 1;

    // декорации
    for (const d of decos) {
      Assets.drawImage(g, d.key, d.tx * T + T / 2, d.ty * T + T, { scale: 1 });
    }
  }

  // волны на воде — рисуем динамически поверх
  function drawWaterOverlay(ctx, cam, time) {
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 2;
    for (const w of waterTiles) {
      const px = w.tx * T - cam.x, py = w.ty * T - cam.y;
      if (px < -T || py < -T || px > cam.w + T || py > cam.h + T) continue;
      const off = Math.sin(time * 1.8 + (w.tx + w.ty) * 1.3) * 3;
      ctx.beginPath();
      ctx.moveTo(px + 10, py + 24 + off);
      ctx.quadraticCurveTo(px + 22, py + 20 + off, px + 32, py + 24 + off);
      ctx.quadraticCurveTo(px + 42, py + 28 + off, px + 54, py + 24 + off);
      ctx.stroke();
    }
    ctx.restore();
  }

  // --- связность карты ---
  function isMineTile(x, y) {
    for (const m of mines) {
      if (x >= m.tx && x < m.tx + 3 && y >= m.ty && y < m.ty + 2) return true;
    }
    return false;
  }

  function removeTreeAt(x, y) {
    const t = trees.find(tr => !tr.dead && tr.tx === x && tr.ty === y);
    if (t) { t.dead = true; t.wood = 0; grid[idx(x, y)] = 0; return true; }
    return false;
  }

  function reachableSet() {
    // BFS от клетки рядом с замком (10,14 — внутри следa замка, стартуем оттуда)
    const reach = new Uint8Array(W * H);
    const q = [];
    const sx = 13, sy = 14; // свободная клетка у правого края замка
    if (grid[idx(sx, sy)] !== 0) return reach;
    reach[idx(sx, sy)] = 1;
    q.push(sx, sy);
    let head = 0;
    while (head < q.length) {
      const cx = q[head], cy = q[head + 1]; head += 2;
      const nb = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (const [dx, dy] of nb) {
        const nx = cx + dx, ny = cy + dy;
        if (!inBounds(nx, ny)) continue;
        const ni = idx(nx, ny);
        if (reach[ni] || grid[ni] !== 0) continue;
        reach[ni] = 1;
        q.push(nx, ny);
      }
    }
    return reach;
  }

  function ensureConnectivity() {
    for (let iter = 0; iter < 24; iter++) {
      const reach = reachableSet();
      // ищем недостижимую свободную клетку
      let ux = -1, uy = -1;
      outer: for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        if (grid[idx(x, y)] === 0 && !reach[idx(x, y)]) { ux = x; uy = y; break outer; }
      }
      if (ux < 0) return; // всё связано
      // прорубаем коридор от этой клетки к замку (на запад), обходя воду/шахты
      let x = ux, y = uy;
      let guard = 0;
      while (guard++ < 200) {
        if (reach[idx(x, y)]) break;
        // шаг на запад; если упираемся в воду/шахту — смещаемся по Y
        let nx = x - 1, ny = y;
        if (!inBounds(nx, ny)) { ny = y + (y > 14 ? -1 : 1); nx = x; }
        else if (grid[idx(nx, ny)] === 3 || isMineTile(nx, ny)) {
          ny = y + (y > 14 ? -1 : 1);
          nx = x;
          if (!inBounds(nx, ny) || grid[idx(nx, ny)] === 3 || isMineTile(nx, ny)) {
            ny = y + (y > 14 ? 1 : -1);
          }
        }
        if (!inBounds(nx, ny)) break;
        removeTreeAt(nx, ny);
        x = nx; y = ny;
        if (grid[idx(x, y)] !== 0) break; // непроходимо и не дерево — стоп
      }
    }
  }

  function treeAt(x, y) {
    return trees.find(t => !t.dead && t.tx === x && t.ty === y) || null;
  }

  return {
    trees, mines, waterTiles, decos, camps,
    W, H, T,
    idx, inBounds, walkable,
    generate, prerender, blockTile,
    get grid() { return grid; },
    get ground() { return groundCanvas; },
    drawWaterOverlay, treeAt,
  };
})();
