/* ===== Tiny Bastion — поиск пути (A* по тайлам) для обхода препятствий ===== */
'use strict';

const Path = (() => {
  const W = CFG.MAP_W, H = CFG.MAP_H;
  const N = W * H;
  const idx = (x, y) => y * W + x;

  // ближайший свободный тайл (если старт/цель внутри препятствия)
  function nearestFree(tx, ty) {
    if (GameMap.inBounds(tx, ty) && GameMap.grid[idx(tx, ty)] === 0) return [tx, ty];
    for (let r = 1; r < 6; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
          const nx = tx + dx, ny = ty + dy;
          if (GameMap.inBounds(nx, ny) && GameMap.grid[idx(nx, ny)] === 0) return [nx, ny];
        }
      }
    }
    return null;
  }

  // прямая видимость между точками мира (с запасом на радиус юнита)
  function los(x0, y0, x1, y1) {
    const T = CFG.TILE;
    const d = Math.hypot(x1 - x0, y1 - y0);
    const steps = Math.max(1, Math.ceil(d / 12));
    for (let i = 1; i < steps; i++) {
      const x = x0 + (x1 - x0) * i / steps;
      const y = y0 + (y1 - y0) * i / steps;
      const tx = Math.floor(x / T), ty = Math.floor(y / T);
      if (!GameMap.inBounds(tx, ty) || GameMap.grid[idx(tx, ty)] !== 0) return false;
    }
    return true;
  }

  // A* 4-связный; возвращает массив точек {x,y} (центры тайлов) или null
  function find(sx, sy, tx, ty) {
    const T = CFG.TILE;
    const s = nearestFree(Math.floor(sx / T), Math.floor(sy / T));
    const e = nearestFree(Math.floor(tx / T), Math.floor(ty / T));
    if (!s || !e) return null;
    const start = idx(s[0], s[1]), goal = idx(e[0], e[1]);
    if (start === goal) return [];

    const g = new Float32Array(N).fill(Infinity);
    const parent = new Int32Array(N).fill(-1);
    const closed = new Uint8Array(N);
    const gx = e[0], gy = e[1];
    const h = (i) => {
      const x = i % W, y = (i / W) | 0;
      return Math.abs(x - gx) + Math.abs(y - gy);
    };
    // простая открытая очередь (сетка крошечная)
    const openArr = [start];
    g[start] = 0;
    const fScore = new Float32Array(N).fill(Infinity);
    fScore[start] = h(start);

    const nb = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    let guard = 0;
    while (openArr.length && guard++ < N * 4) {
      // извлекаем минимум по f
      let bi = 0;
      for (let i = 1; i < openArr.length; i++) {
        if (fScore[openArr[i]] < fScore[openArr[bi]]) bi = i;
      }
      const cur = openArr.splice(bi, 1)[0];
      if (cur === goal) {
        // восстановление пути
        const tiles = [];
        let c = cur;
        while (c !== -1 && c !== start) { tiles.push(c); c = parent[c]; }
        tiles.reverse();
        let pts = tiles.map(i => ({ x: (i % W + 0.5) * T, y: (((i / W) | 0) + 0.5) * T }));
        // сглаживание: выбрасываем точки на прямой видимости
        const out = [];
        let ax = sx, ay = sy, i2 = 0;
        while (i2 < pts.length) {
          let j = pts.length - 1;
          for (; j > i2; j--) if (los(ax, ay, pts[j].x, pts[j].y)) break;
          out.push(pts[j]);
          ax = pts[j].x; ay = pts[j].y;
          i2 = j + 1;
        }
        return out;
      }
      closed[cur] = 1;
      const cx = cur % W, cy = (cur / W) | 0;
      for (const [dx, dy] of nb) {
        const nx = cx + dx, ny = cy + dy;
        if (!GameMap.inBounds(nx, ny)) continue;
        const ni = idx(nx, ny);
        if (closed[ni] || GameMap.grid[ni] !== 0) continue;
        const ng = g[cur] + 1;
        if (ng < g[ni]) {
          g[ni] = ng; fScore[ni] = ng + h(ni); parent[ni] = cur;
          if (!openArr.includes(ni)) openArr.push(ni);
        }
      }
    }
    return null;
  }

  return { find, los };
})();
