/* ===== Tiny Bastion — HUD, миникарта, кнопки, подсказки ===== */
'use strict';

const UI = (() => {
  const $ = (id) => document.getElementById(id);
  let world = null;
  let lastFood = '';
  let hintQueue = [];
  let hintT = 0;

  function init(w) {
    world = w;
    $('btn-mute').addEventListener('click', () => { Sound.setMuted(!Sound.muted); refreshMute(); });
    $('btn-pause').addEventListener('click', () => Game.togglePause());
    refreshMute();
  }

  function refreshMute() {
    $('btn-mute').textContent = Sound.muted ? '🔇' : '🔊';
  }

  function show() { $('hud').classList.remove('hidden'); }
  function hide() { $('hud').classList.add('hidden'); }

  // ---------- верхняя панель ----------
  function refresh() {
    $('res-gold').textContent = Math.floor(world.gold);
    $('res-wood').textContent = Math.floor(world.wood);
    const foodTxt = world.foodUsed + '/' + world.foodMax;
    if (foodTxt !== lastFood) {
      lastFood = foodTxt;
      $('res-food').textContent = foodTxt;
      $('res-food').classList.toggle('low', world.foodUsed >= world.foodMax);
    }
    refreshWave();
  }

  function refreshWave() {
    const info = world.waves.hudInfo();
    const label = $('wave-label');
    label.textContent = info.label;
    label.classList.toggle('danger', info.danger);
    $('wave-timer-fill').style.width = Math.round(info.frac * 100) + '%';
    if (info.t > 0) {
      const m = Math.floor(info.t / 60), s = Math.floor(info.t % 60);
      $('wave-timer-text').textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
    } else {
      $('wave-timer-text').textContent = 'БОЙ';
    }
  }

  // ---------- панель выбора и действий ----------
  function refreshSelection() {
    const sel = world.selection;
    const actions = $('actions');
    actions.innerHTML = '';
    const nameEl = $('selinfo-name');
    const descEl = $('selinfo-desc');

    if (sel.length === 0) {
      nameEl.textContent = 'Ничего не выбрано';
      descEl.textContent = 'Выделите юнитов рамкой (ЛКМ) или здание кликом.';
      return;
    }

    const b = sel.find(e => e.isBuilding);
    if (b) {
      nameEl.textContent = b.st.name + (b.done ? '' : ' (стройка)');
      let txt = b.st.desc + '\nПрочность: ' + Math.ceil(b.hp) + '/' + b.maxHp;
      if (b.kind === 'castle' && b.done) {
        txt += b.queue.length ? '\nОбучение: ' + UNITS[b.queue[0]].name + ' (+' + (b.queue.length - 1) + ' в очереди)' : '';
      }
      descEl.innerHTML = txt.replace(/\n/g, '<br>');
      if (b.kind === 'castle' && b.done) {
        addTrainButton(actions, b, 'pawn', 'Q');
        addTrainButton(actions, b, 'warrior', 'W');
        addTrainButton(actions, b, 'archer', 'E');
      }
      return;
    }

    const units = sel.filter(e => !e.isBuilding);
    if (units.length === 1) {
      const u = units[0];
      nameEl.textContent = u.st.name;
      let txt = u.st.desc + '\nЗдоровье: ' + Math.ceil(u.hp) + '/' + u.maxHp;
      if (u.kind === 'pawn' && u.carry > 0) txt += '\nНесёт: ' + u.carry + (u.carryKind() === 'mine' ? ' золота' : ' дерева');
      descEl.innerHTML = txt.replace(/\n/g, '<br>');
    } else {
      const counts = {};
      units.forEach(u => counts[u.kind] = (counts[u.kind] || 0) + 1);
      nameEl.textContent = 'Отряд (' + units.length + ')';
      descEl.textContent = Object.entries(counts).map(([k, n]) => UNITS[k].name + ' ×' + n).join(', ');
    }

    const hasPawn = units.some(u => u.kind === 'pawn');
    if (hasPawn) {
      addBuildButton(actions, 'house', 'B');
      addBuildButton(actions, 'tower', 'T');
    }
  }

  function costText(cost) {
    const parts = [];
    if (cost.gold) parts.push(cost.gold + ' зол.');
    if (cost.wood) parts.push(cost.wood + ' дер.');
    return parts.join(' ');
  }

  function spriteIcon(kind, isBuilding) {
    const c = document.createElement('canvas');
    c.width = 44; c.height = 44;
    const g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    if (isBuilding) {
      Assets.drawImage(g, kind, 22, 40, { scale: kind === 'castle' ? 0.32 : 0.42 });
    } else {
      const spr = SPRITES[kind];
      Assets.drawFrame(g, spr.img, spr.fw, spr.fh, spr.anims.idle.row, 0, 22, 40, { scale: 0.5, anchorY: spr.anchorY });
    }
    return c;
  }

  function addTrainButton(actions, castle, kind, key) {
    const st = UNITS[kind];
    const btn = document.createElement('button');
    btn.className = 'act-btn';
    btn.appendChild(spriteIcon(kind, false));
    const nm = document.createElement('div'); nm.className = 'act-name'; nm.textContent = st.name; btn.appendChild(nm);
    const cs = document.createElement('div'); cs.className = 'act-cost'; cs.textContent = costText(st.cost) + ' · ' + st.food + '🍖'; btn.appendChild(cs);
    const kk = document.createElement('div'); kk.className = 'act-key'; kk.textContent = key; btn.appendChild(kk);
    const qn = castle.queue.filter(k => k === kind).length;
    if (qn > 0) {
      const q = document.createElement('div'); q.className = 'qcount'; q.textContent = '+' + qn; btn.appendChild(q);
    }
    if (castle.queue.length > 0 && castle.queue[0] === kind) {
      const pr = document.createElement('div'); pr.className = 'prog';
      const fill = document.createElement('div');
      fill.style.width = Math.round(100 * castle.trainT / st.trainTime) + '%';
      pr.appendChild(fill); btn.appendChild(pr);
    }
    const afford = world.canAfford(st.cost) && world.foodUsed + st.food <= world.foodMax;
    if (!afford) btn.classList.add('disabled');
    btn.title = st.desc + ' (' + st.trainTime + ' сек)';
    btn.addEventListener('click', () => { world.trainUnit(kind); Sound.play('click'); });
    actions.appendChild(btn);
  }

  function addBuildButton(actions, kind, key) {
    const st = BUILDINGS[kind];
    const btn = document.createElement('button');
    btn.className = 'act-btn';
    btn.appendChild(spriteIcon(kind, true));
    const nm = document.createElement('div'); nm.className = 'act-name'; nm.textContent = st.name; btn.appendChild(nm);
    const cs = document.createElement('div'); cs.className = 'act-cost'; cs.textContent = costText(st.cost); btn.appendChild(cs);
    const kk = document.createElement('div'); kk.className = 'act-key'; kk.textContent = key; btn.appendChild(kk);
    if (!world.canAfford(st.cost)) btn.classList.add('disabled');
    btn.title = st.desc + ' (' + st.buildTime + ' сек)';
    btn.addEventListener('click', () => { Input.startPlacement(kind); });
    actions.appendChild(btn);
  }

  // ---------- миникарта ----------
  function drawMinimap() {
    const mm = $('minimap');
    const g = mm.getContext('2d');
    const sx = mm.width / (GameMap.W * CFG.TILE);
    const sy = mm.height / (GameMap.H * CFG.TILE);

    g.fillStyle = '#1e3315';
    g.fillRect(0, 0, mm.width, mm.height);

    // вода
    g.fillStyle = '#2d7f8f';
    for (const w of GameMap.waterTiles) {
      g.fillRect(w.tx * CFG.TILE * sx, w.ty * CFG.TILE * sy, CFG.TILE * sx + 0.5, CFG.TILE * sy + 0.5);
    }
    // деревья
    g.fillStyle = '#274d1e';
    for (const t of GameMap.trees) {
      if (t.dead) continue;
      g.fillRect(t.tx * CFG.TILE * sx - 1, t.ty * CFG.TILE * sy - 1, 2.5, 2.5);
    }
    // шахты
    g.fillStyle = '#c9a227';
    for (const m of GameMap.mines) {
      if (m.gold <= 0) continue;
      g.fillRect(m.tx * CFG.TILE * sx - 2, m.ty * CFG.TILE * sy - 2, 5, 5);
    }
    // лагери врагов
    g.fillStyle = '#7a2d1e';
    for (const c of GameMap.camps) {
      g.fillRect(c.tx * CFG.TILE * sx - 2, c.ty * CFG.TILE * sy - 2, 5, 5);
    }
    // здания игрока
    g.fillStyle = '#5aa7e8';
    for (const b of world.buildings) {
      if (!b.alive) continue;
      g.fillRect(b.tx * CFG.TILE * sx, b.ty * CFG.TILE * sy, b.w * CFG.TILE * sx, b.h * CFG.TILE * sy);
    }
    // юниты
    for (const u of world.units) {
      if (!u.alive) continue;
      g.fillStyle = u.faction === 'player' ? '#9fd4ff' : '#ff5a3c';
      g.fillRect(u.x * sx - 1, u.y * sy - 1, 2.5, 2.5);
    }
    // рамка камеры
    const cam = world.cam;
    g.strokeStyle = 'rgba(255,255,255,0.7)';
    g.lineWidth = 1;
    g.strokeRect(cam.x * sx, cam.y * sy, cam.w * sx, cam.h * sy);
  }

  // клик по миникарте -> мировые координаты
  function minimapToWorld(mx, my) {
    const mm = $('minimap');
    return {
      x: (mx / mm.width) * GameMap.W * CFG.TILE,
      y: (my / mm.height) * GameMap.H * CFG.TILE,
    };
  }

  // ---------- подсказки и алерты ----------
  function hint(text, dur = 7) {
    hintQueue.push({ text, dur });
  }
  function updateHints(dt) {
    const box = $('hints');
    if (hintT > 0) {
      hintT -= dt;
      if (hintT <= 0) box.innerHTML = '';
      return;
    }
    if (hintQueue.length > 0) {
      const h = hintQueue.shift();
      hintT = h.dur;
      box.innerHTML = '';
      const div = document.createElement('div');
      div.className = 'hint';
      div.textContent = h.text;
      box.appendChild(div);
    }
  }

  function alert(text, kind) {
    const box = $('alerts');
    const div = document.createElement('div');
    div.className = 'alert' + (kind === 'good' ? ' good' : '');
    div.textContent = text;
    box.appendChild(div);
    setTimeout(() => div.remove(), 2700);
    while (box.children.length > 2) box.firstChild.remove();
  }

  return { init, show, hide, refresh, refreshWave, refreshSelection, drawMinimap, minimapToWorld, hint, updateHints, alert, refreshMute };
})();
