/* ===== Tiny Bastion — менеджер волн ===== */
'use strict';

class WaveManager {
  constructor(world) {
    this.world = world;
    this.wave = 0;                 // текущая (идущая/последняя) волна
    this.timer = CFG.FIRST_WAVE_DELAY;
    this.state = 'build';          // build | spawning | active | done
    this.spawnQueue = [];
    this.spawnT = 0;
    this.warned = false;
  }

  get totalWaves() { return CFG.TOTAL_WAVES; }

  update(dt) {
    const w = this.world;
    if (this.state === 'build') {
      this.timer -= dt;
      if (!this.warned && this.timer <= CFG.WAVE_WARN) {
        this.warned = true;
        Sound.play('waveHorn');
        const camp = GameMap.camps[this.wave % GameMap.camps.length];
        w.alert('Волна ' + (this.wave + 1) + ' приближается с ' + camp.dirName + '!', 'bad');
      }
      if (this.timer <= 0) this.startWave();
    } else if (this.state === 'spawning') {
      this.spawnT -= dt;
      if (this.spawnT <= 0 && this.spawnQueue.length > 0) {
        const job = this.spawnQueue.shift();
        w.spawnEnemy(job.kind, job.camp);
        this.spawnT = 0.7 + Math.random() * 0.4;
      }
      if (this.spawnQueue.length === 0) this.state = 'active';
    } else if (this.state === 'active') {
      if (w.enemyCount() === 0) {
        if (this.wave >= this.totalWaves) {
          this.state = 'done';
          w.victory();
        } else {
          this.state = 'build';
          this.timer = CFG.WAVE_INTERVAL;
          this.warned = false;
          w.alert('Волна отбита! Следующая через ' + CFG.WAVE_INTERVAL + ' сек.', 'good');
        }
      }
    }
  }

  startWave() {
    const def = WAVE_TABLE[Math.min(this.wave, WAVE_TABLE.length - 1)];
    this.wave++;
    this.spawnQueue.length = 0;
    // лагеря чередуются; в поздних волнах — сразу несколько
    const campIdx = [(this.wave - 1) % GameMap.camps.length];
    if (this.wave >= 4) campIdx.push((this.wave) % GameMap.camps.length);
    if (this.wave >= 7) campIdx.push((this.wave + 1) % GameMap.camps.length);

    const kinds = [];
    for (let i = 0; i < def.torch; i++) kinds.push('torch');
    for (let i = 0; i < def.tnt; i++) kinds.push('tnt');
    // перемешать
    for (let i = kinds.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [kinds[i], kinds[j]] = [kinds[j], kinds[i]];
    }
    kinds.forEach((kind, i) => {
      const camp = GameMap.camps[campIdx[i % campIdx.length]];
      this.spawnQueue.push({ kind, camp });
    });
    this.state = 'spawning';
    this.spawnT = 0;
    this.world.alert('ВОЛНА ' + this.wave + '!', 'bad');
    Sound.play('waveHorn');
    UI.refreshWave();
  }

  // для HUD: текст и прогресс
  hudInfo() {
    if (this.state === 'build') {
      return {
        label: 'Волна ' + (this.wave + 1) + '/' + this.totalWaves,
        t: this.timer,
        frac: 1 - this.timer / (this.wave === 0 ? CFG.FIRST_WAVE_DELAY : CFG.WAVE_INTERVAL),
        danger: this.timer <= CFG.WAVE_WARN,
      };
    }
    return {
      label: 'Волна ' + this.wave + '/' + this.totalWaves + ' — БОЙ!',
      t: 0, frac: 1, danger: true,
    };
  }
}
