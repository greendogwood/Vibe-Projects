#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Отчёт по договорам на дату.

По каждой работе: цена, выплачено (прямые платежи + распределённый аванс),
осталось оплатить. По каждому договору: итоги и замечания.

Запуск:
    python report.py --data <папка с csv> --date ГГГГ-ММ-ДД [--csv файл.csv]

Пример:
    python report.py --data ../data --date 2026-11-10 --csv report_2026-11-10.csv

Деньги считаются в Decimal (копейки, без float).
Стандартная библиотека Python 3.8+, внешних зависимостей нет.
"""

import argparse
import csv
import sys
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from pathlib import Path

ZERO = Decimal("0.00")


# ---------------------------------------------------------------- модель

@dataclass
class Contract:
    contract_id: str
    contractor: str
    amount: Decimal
    signed_at: date


@dataclass
class Work:
    work_id: str
    contract_id: str
    title: str
    price: Decimal
    status_export: str          # статус на момент выгрузки
    completed_at: date | None
    cancelled_at: date | None
    # дальше — результаты расчёта
    status_on_date: str = ""    # статус, пересчитанный на дату отчёта
    paid_direct: Decimal = ZERO     # платежи, привязанные к работе
    paid_advance: Decimal = ZERO    # доля аванса, отнесённая на работу
    paid_total: Decimal = ZERO
    remaining: Decimal = ZERO


@dataclass
class Payment:
    payment_id: str
    contract_id: str
    work_id: str | None
    purpose: str
    amount: Decimal
    status: str
    created_at: date
    paid_at: date | None
    refunded_at: date | None


@dataclass
class ContractReport:
    contract: Contract
    works: list = field(default_factory=list)          # list[Work]
    paid_total: Decimal = ZERO       # все деньги, реально у подрядчика на дату
    allocated: Decimal = ZERO        # из них распределено на работы
    unallocated: Decimal = ZERO      # из них не покрыто работами (переплата)
    remaining: Decimal = ZERO        # сумма «осталось» по активным работам
    active_works_sum: Decimal = ZERO
    queued_sum: Decimal = ZERO       # платежи в очереди (не оплачены)
    notes: list = field(default_factory=list)          # замечания/аномалии


# ---------------------------------------------------------------- чтение csv

def parse_date(s: str) -> date | None:
    s = (s or "").strip()
    return date.fromisoformat(s) if s else None


def parse_money(s: str) -> Decimal:
    return Decimal((s or "0").strip().replace(" ", "").replace(",", ".")).quantize(ZERO)


def load_data(data_dir: Path):
    with open(data_dir / "contracts.csv", encoding="utf-8-sig", newline="") as f:
        contracts = {
            r["contract_id"]: Contract(
                contract_id=r["contract_id"],
                contractor=r["contractor"],
                amount=parse_money(r["amount"]),
                signed_at=parse_date(r["signed_at"]),
            )
            for r in csv.DictReader(f)
        }

    works = []
    with open(data_dir / "works.csv", encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            works.append(Work(
                work_id=r["work_id"],
                contract_id=r["contract_id"],
                title=r["title"],
                price=parse_money(r["price"]),
                status_export=r["status"],
                completed_at=parse_date(r["completed_at"]),
                cancelled_at=parse_date(r["cancelled_at"]),
            ))

    payments = []
    with open(data_dir / "payments.csv", encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            payments.append(Payment(
                payment_id=r["payment_id"],
                contract_id=r["contract_id"],
                work_id=r["work_id"].strip() or None,
                purpose=r["purpose"],
                amount=parse_money(r["amount"]),
                status=r["status"],
                created_at=parse_date(r["created_at"]),
                paid_at=parse_date(r["paid_at"]),
                refunded_at=parse_date(r["refunded_at"]),
            ))

    return contracts, works, payments


# ---------------------------------------------------------------- расчёт

def work_status_on(w: Work, d: date) -> str:
    """Статус работы на дату отчёта (пересчитанный по датам, а не из выгрузки)."""
    if w.cancelled_at and w.cancelled_at <= d:
        return "cancelled"
    if w.completed_at and w.completed_at <= d:
        return "done"
    return "planned"


def paid_amount_on(p: Payment, d: date) -> Decimal:
    """Сколько денег по платежу реально у подрядчика на дату d."""
    if p.status == "queued":
        return ZERO                      # в очереди — деньги не ушли
    if not p.paid_at or p.paid_at > d:
        return ZERO                      # на дату отчёта ещё не оплачен
    if p.refunded_at and p.refunded_at <= d:
        return ZERO                      # к дате отчёта деньги вернули
    return p.amount


def build_report(contracts, works, payments, as_of: date) -> list:
    reports = []
    for cid in sorted(contracts):
        rep = ContractReport(contract=contracts[cid])
        c_works = sorted((w for w in works if w.contract_id == cid),
                         key=lambda w: w.work_id)
        c_pays = [p for p in payments if p.contract_id == cid]

        # 1. Прямые платежи — на свою работу; авансы — в общий «котёл».
        pool = ZERO
        for p in c_pays:
            amt = paid_amount_on(p, as_of)
            if p.status == "queued":
                rep.queued_sum += p.amount
            if p.work_id:
                w = next((x for x in c_works if x.work_id == p.work_id), None)
                if w is None:
                    rep.notes.append(
                        f"платёж {p.payment_id} ссылается на неизвестную работу {p.work_id}")
                    pool += amt
                else:
                    w.paid_direct += amt
            else:
                pool += amt

        # 2. Статусы работ на дату отчёта.
        for w in c_works:
            w.status_on_date = work_status_on(w, as_of)

        # 3. Аванс «накрывает» активные работы по порядку (водопад).
        for w in c_works:
            if w.status_on_date == "cancelled":
                continue
            need = max(ZERO, w.price - w.paid_direct)
            take = min(need, pool)
            w.paid_advance = take
            pool -= take

        # 4. Итоги по работам.
        for w in c_works:
            w.paid_total = w.paid_direct + w.paid_advance
            if w.status_on_date == "cancelled":
                w.remaining = ZERO
                if w.paid_total > ZERO:
                    rep.notes.append(
                        f"по отменённой работе {w.work_id} есть оплата "
                        f"{fmt(w.paid_total)} — нужен возврат или перенос")
            else:
                w.remaining = max(ZERO, w.price - w.paid_total)
                if w.paid_total > w.price:
                    rep.notes.append(
                        f"по работе {w.work_id} оплачено больше цены "
                        f"на {fmt(w.paid_total - w.price)}")

        # 5. Итоги по договору.
        rep.works = c_works
        rep.paid_total = sum((w.paid_total for w in c_works), ZERO) + pool
        rep.allocated = rep.paid_total - pool
        rep.unallocated = pool
        rep.active_works_sum = sum(
            (w.price for w in c_works if w.status_on_date != "cancelled"), ZERO)
        rep.remaining = sum(
            (w.remaining for w in c_works if w.status_on_date != "cancelled"), ZERO)

        if rep.unallocated > ZERO:
            rep.notes.append(
                f"оплачено на {fmt(rep.unallocated)} больше, чем цена активных работ")
        if rep.contract.amount != rep.active_works_sum:
            rep.notes.append(
                f"сумма договора {fmt(rep.contract.amount)} не равна сумме активных "
                f"работ {fmt(rep.active_works_sum)} (разница "
                f"{fmt(rep.contract.amount - rep.active_works_sum)}) — уточнить, "
                f"действует ли договор на полную сумму")
        if rep.queued_sum > ZERO:
            rep.notes.append(
                f"в очереди на оплату {fmt(rep.queued_sum)} — в отчёт не входит")

        reports.append(rep)
    return reports


# ---------------------------------------------------------------- вывод

def fmt(d: Decimal) -> str:
    """100 000.00"""
    return f"{d:,.2f}".replace(",", " ")


STATUS_RU = {"done": "выполнена", "planned": "запланирована", "cancelled": "отменена"}


def print_report(reports, as_of: date):
    print(f"ОТЧЁТ ПО ДОГОВОРАМ на {as_of.strftime('%d.%m.%Y')}")
    for rep in reports:
        c = rep.contract
        print()
        print(f"Договор {c.contract_id} — {c.contractor} "
              f"(сумма договора {fmt(c.amount)}, подписан "
              f"{c.signed_at.strftime('%d.%m.%Y')})")
        header = ("Работа", "Название", "Статус", "Цена",
                  "Оплачено напрямую", "Из аванса", "Всего выплачено", "Осталось")
        rows = []
        for w in rep.works:
            rows.append((
                w.work_id, w.title, STATUS_RU[w.status_on_date],
                fmt(w.price), fmt(w.paid_direct), fmt(w.paid_advance),
                fmt(w.paid_total), fmt(w.remaining),
            ))
        widths = [max(len(h), *(len(r[i]) for r in rows)) if rows else len(h)
                  for i, h in enumerate(header)]
        line = "  ".join(h.ljust(widths[i]) for i, h in enumerate(header))
        print(line)
        print("-" * len(line))
        for r in rows:
            print("  ".join(
                (r[i].rjust(widths[i]) if i >= 3 else r[i].ljust(widths[i]))
                for i in range(len(header))))
        print(f"Итого по договору: выплачено {fmt(rep.paid_total)} "
              f"(распределено на работы {fmt(rep.allocated)}, "
              f"не распределено {fmt(rep.unallocated)}); "
              f"осталось оплатить {fmt(rep.remaining)}")
        for note in rep.notes:
            print(f"  ! {note}")


def write_csv(reports, as_of: date, path: Path):
    # Разделитель ';', чтобы файл без настроек открывался в русском Excel.
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        wr = csv.writer(f, delimiter=";")
        wr.writerow(["Отчёт на", as_of.isoformat()])
        wr.writerow([])
        for rep in reports:
            c = rep.contract
            wr.writerow([f"Договор {c.contract_id}", c.contractor,
                         f"сумма договора {fmt(c.amount)}"])
            wr.writerow(["work_id", "Название", "Статус на дату отчёта", "Цена",
                         "Оплачено напрямую", "Из аванса", "Всего выплачено",
                         "Осталось оплатить"])
            for w in rep.works:
                wr.writerow([w.work_id, w.title, STATUS_RU[w.status_on_date],
                             str(w.price), str(w.paid_direct), str(w.paid_advance),
                             str(w.paid_total), str(w.remaining)])
            wr.writerow(["ИТОГО", "", "", str(rep.active_works_sum), "", "",
                         str(rep.paid_total), str(rep.remaining)])
            for note in rep.notes:
                wr.writerow(["!", note])
            wr.writerow([])


# ---------------------------------------------------------------- main

def main(argv=None):
    ap = argparse.ArgumentParser(description="Отчёт по договорам на дату")
    ap.add_argument("--data", required=True, type=Path,
                    help="папка с contracts.csv, works.csv, payments.csv")
    ap.add_argument("--date", required=True, type=date.fromisoformat,
                    help="дата отчёта, ГГГГ-ММ-ДД (например 2026-11-10)")
    ap.add_argument("--csv", type=Path, default=None,
                    help="куда сохранить CSV (по умолчанию только консоль)")
    args = ap.parse_args(argv)

    contracts, works, payments = load_data(args.data)
    reports = build_report(contracts, works, payments, args.date)

    print_report(reports, args.date)
    if args.csv:
        write_csv(reports, args.date, args.csv)
        print(f"\nCSV сохранён: {args.csv}")


if __name__ == "__main__":
    sys.exit(main())
